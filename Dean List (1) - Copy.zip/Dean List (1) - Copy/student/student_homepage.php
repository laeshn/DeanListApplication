<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '0');
session_start();

// Check if user is logged in as student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: student_login.php');
    exit();
}

require_once __DIR__ . '/../config/database.php';

function asset($file) {
    $base = dirname($_SERVER['SCRIPT_NAME']);
    if ($base === '/' || $base === '\\' || $base === '.') {
        $base = '';
    }
    return ($base === '' ? '' : rtrim($base, '/')) . '/' . ltrim($file, '/');
}

// Get student information from session
$fullName   = $_SESSION['full_name'] ?? 'Unknown';
$student_id = $_SESSION['student_id'] ?? 'N/A';
$yearLevel  = $_SESSION['year_level'] ?? 'N/A';
$course     = $_SESSION['course'] ?? '';

// Get current semester and academic year from database
$database = new Database();
$db = $database->getConnection();

$currentSemester = 'Not Set';
$currentAcadYear = 'Not Set';
$studentRanking = null;
$appStatus = 'unknown';
$latestApplication = null;
$hasApplication = false;
$applicationStatus = 'No pending applications.';

try {
    // Get current semester number
    $semQuery = "SELECT semester_number FROM current_semester ORDER BY id DESC LIMIT 1";
    $semStmt = $db->prepare($semQuery);
    $semStmt->execute();
    $semesterData = $semStmt->fetch(PDO::FETCH_ASSOC);
    
    // Get latest academic year
    $acadQuery = "SELECT * FROM acad_year ORDER BY acadID DESC LIMIT 1";
    $acadStmt = $db->prepare($acadQuery);
    $acadStmt->execute();
    $acadYearData = $acadStmt->fetch(PDO::FETCH_ASSOC);
    
    // Get application status
    $statusQuery = "SELECT status FROM application_status ORDER BY id DESC LIMIT 1";
    $statusStmt = $db->prepare($statusQuery);
    $statusStmt->execute();
    $statusData = $statusStmt->fetch(PDO::FETCH_ASSOC);
    if ($statusData) {
        $appStatus = $statusData['status'];
    }
    
    if ($semesterData) {
        $semNum = $semesterData['semester_number'];
        $currentSemester = ($semNum == '1' ? '1st' : ($semNum == '2' ? '2nd' : $semNum)) . ' Semester';
    }
    
    if ($acadYearData) {
        $currentAcadYear = date('Y', strtotime($acadYearData['start_date'])) . '-' . date('Y', strtotime($acadYearData['end_date']));
    }
    
    // Get student's latest application and stats
    if ($student_id != 'N/A') {
        $appQuery = "SELECT * FROM applications WHERE student_id = ? ORDER BY created_at DESC LIMIT 1";
        $appStmt = $db->prepare($appQuery);
        $appStmt->execute([$student_id]);
        $latestApplication = $appStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($latestApplication) {
            $hasApplication = true;
            $status = ucfirst($latestApplication['status']);
            if ($latestApplication['status'] == 'under-review') {
                $applicationStatus = 'Application under review';
            } elseif ($latestApplication['status'] == 'accepted') {
                $applicationStatus = 'Application accepted';
            } elseif ($latestApplication['status'] == 'rejected') {
                $applicationStatus = 'Application rejected';
            }
        }
        
        // Get student ranking from current rankings (filtered by course and year)
    if ($student_id != 'N/A') {
        $rankQuery = "SELECT sr.*, 
                             cs.semester_number,
                             ay.academic_year,
                             (SELECT COUNT(*) + 1 FROM student_rankings sr2 
                              WHERE CAST(sr2.gpa AS DECIMAL(4,2)) < CAST(sr.gpa AS DECIMAL(4,2)) 
                              AND sr2.semID = sr.semID AND sr2.acadID = sr.acadID 
                              AND sr2.course = sr.course AND sr2.year_level = sr.year_level) as current_rank,
                             (SELECT COUNT(*) FROM student_rankings sr3 
                              WHERE sr3.semID = sr.semID AND sr3.acadID = sr.acadID 
                              AND sr3.course = sr.course AND sr3.year_level = sr.year_level) as total_students
                      FROM student_rankings sr 
                      LEFT JOIN semester sem ON sem.semID = sr.semID
                      LEFT JOIN acad_year ay ON ay.acadID = sr.acadID
                      LEFT JOIN current_semester cs ON 1=1
                      WHERE sr.student_id = ? 
                      ORDER BY sr.id DESC LIMIT 1";
        $rankStmt = $db->prepare($rankQuery);
        $rankStmt->execute([$student_id]);
        $studentRanking = $rankStmt->fetch(PDO::FETCH_ASSOC);
        if ($studentRanking === false) $studentRanking = null;
        
        // Get previous semester ranking from archive
        $prevRankQuery = "SELECT ra.*, ra.final_rank as prev_rank,
                                 cs.semester_number,
                                 ay.academic_year,
                                 (SELECT COUNT(*) FROM rankings_archive ra2 
                                  WHERE ra2.semID = ra.semID AND ra2.acadID = ra.acadID) as prev_total_students
                          FROM rankings_archive ra 
                          LEFT JOIN semester sem ON sem.semID = ra.semID
                          LEFT JOIN acad_year ay ON ay.acadID = ra.acadID
                          LEFT JOIN current_semester cs ON 1=1
                          WHERE ra.student_id = ? 
                          ORDER BY ra.id DESC LIMIT 1";
        $prevStmt = $db->prepare($prevRankQuery);
        $prevStmt->execute([$student_id]);
        $previousRanking = $prevStmt->fetch(PDO::FETCH_ASSOC);
        if ($previousRanking === false) $previousRanking = null;
    }
    }
    
} catch (Exception $e) {
    // Keep default values if error
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Dashboard - Dean's List</title>
  <link rel="stylesheet" href="<?php echo asset('student_homepage.css'); ?>">
</head>

<body>
  <!-- Header -->
  <header class="student-header">
    <div class="student-header-inner">
      <div class="student-info">
        <div class="profile-link">
          <a href="<?php echo asset('student_profile_new.php'); ?>" style="text-decoration: none; color: inherit;">
            <div class="profile-icon">
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="8" r="5" fill="currentColor"/>
                <path d="M4 20C4 16.134 7.582 13 12 13C16.418 13 20 16.134 20 20" fill="currentColor"/>
              </svg>
            </div>
          </a>
          <div class="header-text">
            <h1>Welcome back, <span><?php echo htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8'); ?></span>!</h1>
            <p>Student ID: <?php echo htmlspecialchars($student_id, ENT_QUOTES, 'UTF-8'); ?> • Year Level: <?php echo htmlspecialchars($yearLevel, ENT_QUOTES, 'UTF-8'); ?> • <?php echo htmlspecialchars($course, ENT_QUOTES, 'UTF-8'); ?></p>
          </div>
        </div>
      </div>
      <div class="student-actions">
        <a class="btn-view-apps" href="<?php echo asset('student_profile_new.php'); ?>">My Profile</a>
        <a class="btn-view-apps" href="<?php echo asset('../shared/application_status.php'); ?>">View Applications</a>
        <a class="logout" href="<?php echo asset('student_logout.php'); ?>">Logout</a>
      </div>
    </div>
  </header>

  <!-- Main Content with Wave -->
  <main class="student-main">
    <!-- Top Banner Section -->
    <section class="top-banner">
      
      <div class="banner-content">
        <div class="banner-left">
          <div class="banner-badge" style="background: <?php echo $appStatus == 'open' ? '#10b981' : '#ef4444'; ?>">
            <?php echo strtoupper($appStatus); ?>
          </div>
          <h2>Dean's List Application</h2>
          <?php if ($appStatus == 'open'): ?>
            <p>Pass your requirements on time to be eligible for Dean's List recognition.</p>
          <?php else: ?>
            <p>Applications are currently closed. Check back next semester.</p>
          <?php endif; ?>

        </div>
        <div class="banner-right">
          <a href="<?php echo asset('../shared/application.php'); ?>" class="btn-apply-now">Apply Now</a>
        </div>
      </div>
    </section>

    <!-- Achievement Section -->
    <section class="achievement-section">
      <div class="achievement-container">
        <div class="achievement-left">
          <h3>Previous Semester Achievement</h3>
          <p><?php 
            if (isset($previousRanking)) {
                $prevSemNum = $previousRanking['semester_number'] ?? '';
                $prevSemDisplay = $prevSemNum == '1' ? '1st Semester' : ($prevSemNum == '2' ? '2nd Semester' : 'Semester');
                echo htmlspecialchars($prevSemDisplay) . ' Dean\'s List Recognition';
            } else {
                echo 'No Previous Semester Data';
            }
          ?></p>
        </div>
        <div class="achievement-right">
          <div class="achievement-stat">
            <div class="stat-circle">
              <span class="stat-icon">🎖️</span>
              <div class="stat-info">
                <div class="stat-label">Rank</div>
                <div class="stat-value"><?php echo isset($previousRanking) ? '#'.$previousRanking['prev_rank'] : 'N/A'; ?></div>
              </div>
            </div>
          </div>
          <div class="achievement-stat">
            <div class="stat-circle">
              <span class="stat-icon">📊</span>
              <div class="stat-info">
                <div class="stat-label">GPA</div>
                <div class="stat-value"><?php echo isset($previousRanking) ? htmlspecialchars($previousRanking['gpa']) : 'N/A'; ?></div>
              </div>
            </div>
          </div>
          <div class="achievement-stat">
            <div class="stat-circle">
              <span class="stat-icon">📈</span>
              <div class="stat-info">
                <div class="stat-label">Percentile</div>
                <div class="stat-value"><?php 
                  if (isset($previousRanking) && $previousRanking['prev_total_students'] > 0) {
                    $prevPercentile = round((($previousRanking['prev_total_students'] - $previousRanking['prev_rank'] + 1) / $previousRanking['prev_total_students']) * 100);
                    echo $prevPercentile . '%';
                  } else {
                    echo 'N/A';
                  }
                ?></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Cards Section -->
    <section class="cards-section">
      <div class="cards-container">
        <div class="card">
          <h4>Dean's List Ranking</h4>
          <?php if ($studentRanking && is_array($studentRanking)): ?>
            <div class="card-rank">
              <?php 
                $rank = $studentRanking['current_rank'] ?? 0;
                if ($rank == 1) echo '🏆 #1';
                elseif ($rank == 2) echo '🥈 #2';
                elseif ($rank == 3) echo '🥉 #3';
                else echo '#' . $rank;
              ?>
            </div>
            <div class="progress-wrapper">
              <div class="progress">
                <?php 
                  $totalStudents = $studentRanking['total_students'] ?? 0;
                  $percentage = $totalStudents > 0 ? 
                    round((($totalStudents - $rank + 1) / $totalStudents) * 100) : 0;
                ?>
                <div class="progress-bar" style="width: <?php echo $percentage; ?>%"></div>
              </div>
            </div>
            <p>Top <?php echo $percentage; ?>% in <?php echo htmlspecialchars($course); ?> (<?php echo $totalStudents; ?> students)</p>
            <small>GPA: <?php echo htmlspecialchars($studentRanking['gpa'] ?? 'N/A'); ?> | Semester: <?php 
              $semNum = $studentRanking['semester_number'] ?? '';
              $semDisplay = $semNum == '1' ? '1st Semester' : ($semNum == '2' ? '2nd Semester' : 'N/A');
              echo htmlspecialchars($semDisplay);
            ?></small>
          <?php elseif ($hasApplication && $latestApplication['status'] == 'accepted'): ?>
            <div class="card-rank">Processing</div>
            <p>Ranking being generated...</p>
          <?php elseif ($hasApplication): ?>
            <div class="card-rank">Pending</div>
            <p>Ranking will be available when application is accepted</p>
          <?php else: ?>
            <div class="card-rank">No Application</div>
            <p>Submit an application to see your ranking</p>
          <?php endif; ?>
        </div>

        <div class="card">
          <h4>Current Semester</h4>
          <p class="semester-period" style="font-size: 1.2em; font-weight: bold;"><?php echo htmlspecialchars($currentSemester); ?></p>
          <p style="font-size: 1.1em; margin-top: 8px;">Academic Year: <?php echo htmlspecialchars($currentAcadYear); ?></p>
        </div>

        <div class="card">
          <h4>Application Status</h4>
          <div class="status-badge" style="background: <?php 
            if (!$hasApplication) echo '#10b981'; // green for ready
            elseif ($latestApplication['status'] == 'under-review') echo '#f59e0b'; // yellow for pending
            elseif ($latestApplication['status'] == 'accepted') echo '#10b981'; // green for accepted
            else echo '#ef4444'; // red for rejected
          ?>"><?php 
            if (!$hasApplication) echo 'Ready to Apply';
            elseif ($latestApplication['status'] == 'under-review') echo 'Under Review';
            elseif ($latestApplication['status'] == 'accepted') echo 'Accepted';
            else echo 'Rejected';
          ?></div>
          <p><?php echo htmlspecialchars($applicationStatus); ?></p>
        </div>
      </div>
    </section>
  </main>

  <!-- Floating Action Button -->
  <a href="<?php echo asset('../shared/application_status.php'); ?>" class="fab" title="View Applications">📄</a>

</body>
</html>
