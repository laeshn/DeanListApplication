<?php
session_start();
require_once '../config/database.php';

// Debug toggle
$debug = true;
$debug_info = [];

function asset($file) {
    $base = dirname($_SERVER['SCRIPT_NAME']);
    if ($base === '/' || $base === '\\' || $base === '.') {
        $base = '';
    }
    return ($base === '' ? '' : rtrim($base, '/')) . '/' . ltrim($file, '/');
}

$error_message = '';
$current_time = date('Y-m-d H:i:s');
$current_user = 'czam-exe';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = new Database();
    $db = $database->getConnection();

    $student_id_input = $_POST['student_id'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!empty($student_id_input) && !empty($password)) {
        try {
            // ✅ Use student ID as-is (with dashes)
            $student_id = $student_id_input;

            // Select from new database structure
            $query = "SELECT 
                        u.user_id, u.email, u.password, u.role,
                        s.student_id, s.full_name, s.course, s.year_level
                      FROM users u
                      JOIN students s ON u.student_id = s.student_id
                      WHERE s.student_id = :student_id 
                        AND u.role = 'student'";
            $stmt = $db->prepare($query);
            $stmt->bindParam(":student_id", $student_id);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($password === $user['password']) {
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['student_id'] = $user['student_id'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['course'] = $user['course'];
                    $_SESSION['year_level'] = $user['year_level'];

                    if ($debug) {
                        error_log('Login successful. Session data: ' . print_r($_SESSION, true));
                    }

                    header("Location: student_homepage.php");
                    exit();
                } else {
                    $error_message = "Invalid password";
                }
            } else {
                $error_message = "Invalid student credentials";
            }
        } catch (PDOException $e) {
            $error_message = "Database error occurred";
            if ($debug) {
                $debug_info[] = "Database error: " . $e->getMessage();
            }
        }
    } else {
        $error_message = "Please enter both student ID and password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Student Login - Dean's List</title>
    <link rel="stylesheet" href="<?php echo asset('../login.css'); ?>" />
</head>
<body>
    <div class="background-blur"></div>

    <header>
        <img src="<?php echo asset('../resource/logo.png'); ?>" alt="LSPU Logo" class="logo" />
        <h1>DEAN'S LIST APPLICATION</h1>
    </header>

    <main style="display:flex; justify-content:center; padding-top:40px;">
        <section class="portal student-login" style="max-width:420px; width:100%;">
            <div class="icon">
                <!-- student icon -->
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                    <path d="M12 2L1 7l11 5 9-4.09V17a2 2 0 0 1-2 2h-1" stroke="#2b6cb0" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M12 22v-7" stroke="#2b6cb0" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            <h2>Student Portal</h2>
            <p>Log in to your LSPU Account</p>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div style="color:#fff;background:#10b981;padding:10px;border-radius:8px;margin:10px 0;">
                    <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($error_message)): ?>
                <div style="color:#fff;background:#ef4444;padding:10px;border-radius:8px;margin:10px 0;">
                    <?php echo htmlspecialchars($error_message, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>

            <form method="post" action="" style="display:block;">
                <label for="student_id">Student ID</label>
                <input id="student_id" name="student_id" type="text" placeholder="2023-0001" 
                       style="display:block; width:100%; padding:12px; margin:10px 0 18px; border-radius:8px; border:1px solid #eee; background:#f7f7f8;" required />

                <label for="password">Password</label>
                <input id="password" name="password" type="password" 
                       style="display:block; width:100%; padding:12px; margin:10px 0 18px; border-radius:8px; border:1px solid #eee; background:#f7f7f8;" required />

                <button type="submit" class="btn student-btn" style="text-align:center;">Log In</button>
            </form>

            <div style="text-align:center; margin-top:1rem;">
                <a href="forgot_password.php" style="color:#4a5568; text-decoration:none; font-size:14px;">Forgot Password?</a>
                <br><br>
                <a href="../register.php" style="color:#4a5568; text-decoration:none;">
                    Don't have an account? Register here
                </a>
            </div>
        </section>
    </main>
</body>
</html>
