<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in as student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: student_login.php');
    exit();
}

function asset($file) {
    $base = dirname($_SERVER['SCRIPT_NAME']);
    if ($base === '/' || $base === '\\' || $base === '.') {
        $base = '';
    }
    return ($base === '' ? '' : rtrim($base, '/')) . '/' . ltrim($file, '/');
}

$database = new Database();
$db = $database->getConnection();
$student_id = $_SESSION['student_id'];
$success_message = '';
$error_message = '';
$show_edit = isset($_GET['edit']) && $_GET['edit'] == '1';

// Handle profile picture upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['profile_picture'])) {
    $uploadDir = __DIR__ . '/uploads/profiles/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $file = $_FILES['profile_picture'];
    if ($file['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
        if (in_array($file['type'], $allowedTypes) && $file['size'] <= 5 * 1024 * 1024) {
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'profile_' . $student_id . '_' . time() . '.' . $extension;
            $filepath = $uploadDir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                // Update database with profile picture path
                $stmt = $db->prepare("UPDATE students SET profile_picture = ? WHERE student_id = ?");
                $stmt->execute(['uploads/profiles/' . $filename, $student_id]);
                $success_message = "Profile picture updated successfully!";
            } else {
                $error_message = "Failed to upload profile picture.";
            }
        } else {
            $error_message = "Invalid file type or size. Please upload JPG/PNG under 5MB.";
        }
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    if (!empty($new_password) && !empty($confirm_password)) {
        if ($new_password === $confirm_password) {
            try {
                $update_password = "UPDATE users SET password = ? WHERE student_id = ?";
                $stmt = $db->prepare($update_password);
                $stmt->execute([$new_password, $student_id]);
                
                $success_message = "Password changed successfully!";
            } catch (Exception $e) {
                $error_message = "Error changing password: " . $e->getMessage();
            }
        } else {
            $error_message = "Passwords do not match!";
        }
    } else {
        $error_message = "Please fill in both password fields.";
    }
}

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $course = $_POST['course'] ?? '';
    $year_level = $_POST['year_level'] ?? '';
    
    if (!empty($full_name) && !empty($email) && !empty($course) && !empty($year_level)) {
        try {
            $db->beginTransaction();
            
            // Update students table (including year_level)
            $update_student = "UPDATE students SET full_name = ?, course = ?, year_level = ? WHERE student_id = ?";
            $stmt1 = $db->prepare($update_student);
            $stmt1->execute([$full_name, $course, $year_level, $student_id]);
            
            // Update users table
            $update_user = "UPDATE users SET email = ? WHERE student_id = ?";
            $stmt2 = $db->prepare($update_user);
            $stmt2->execute([$email, $student_id]);
            
            $db->commit();
            
            // Update session data
            $_SESSION['full_name'] = $full_name;
            $_SESSION['course'] = $course;
            $_SESSION['year_level'] = $year_level;
            
            $success_message = "Profile updated successfully!";
            $show_edit = false;
        } catch (Exception $e) {
            $db->rollBack();
            $error_message = "Error updating profile: " . $e->getMessage();
        }
    } else {
        $error_message = "All fields are required.";
    }
}

// Get current student data
try {
    $query = "SELECT s.*, u.email, u.created_at as registration_date 
              FROM students s 
              JOIN users u ON s.student_id = u.student_id 
              WHERE s.student_id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$student_id]);
    $student_data = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $error_message = "Error loading profile data.";
    $student_data = null;
}

$profile_picture = $student_data['profile_picture'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Dean's List</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
        }
        
        .header {
            background: white;
            padding: 20px 0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .back-btn {
            padding: 10px 20px;
            margin-right: 30px ;
            color: grey;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
        }
        
        .header h1 {
            color: #333;
            font-size: 24px;
        }
        
        .main-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 0 20px;
        }
        
        .profile-card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .profile-header {
            background: linear-gradient(90deg, #e07b2a 0%, #d66b1a 100%);
            padding: 40px;
            text-align: center;
            color: black;
            position: relative;
        }
        
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            margin: 0 auto 20px;
            border: 4px solid rgba(255,255,255,0.9);
            overflow: hidden;
            position: relative;
            cursor: pointer;
        }
        
        .profile-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .profile-avatar .default-avatar {
            width: 100%;
            height: 100%;
            background: rgba(255,255,255,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
        }
        
        .upload-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s;
            color: white;
            font-size: 12px;
        }
        
        .profile-avatar:hover .upload-overlay {
            opacity: 1;
        }
        
        .profile-info h2 {
            color: white;
            font-size: 28px;
            margin-bottom: 8px;
        }
        
        .student-id {
            color:white;
            font-size: 16px;
            opacity: 0.9;
        }
        
        .profile-content {
            padding: 40px;
        }
        
        .info-section {
            margin-bottom: 30px;
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .section-title {
            font-size: 20px;
            color: #333;
            font-weight: 600;
        }
        
        .settings-btn {
            padding: 8px 8px;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            font-size: 20px;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        
        .info-item {
            padding: 20px;
            background: #f9fafb;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
        }
        
        .info-label {
            font-size: 12px;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
            font-weight: 600;
        }
        
        .info-value {
            font-size: 16px;
            color: #111827;
            font-weight: 500;
            overflow: auto;
        }
        
        .edit-form {
            display: none;
            background: #f9fafb;
            padding: 30px;
            border-radius: 12px;
            margin-top: 20px;
        }
        
        .edit-form.show {
            display: block;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #374151;
        }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
        }
        
        .btn-group {
            display: flex;
            gap: 12px;
            margin-top: 20px;
        }
        
        @media (max-width: 768px) { 
            .btn-group { 
                display: block; 
                
            } 
            
            .btn{
                margin-top: 10px;
                width: 100%;
                text-align: center;
                
            }
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
        }
        
        .btn-primary {
            background: #10b981;
            color: white;
        }
        
        .btn-secondary {
            background: #6b7280;
            color: white;
        }
        
        .message {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .error {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        
        .hidden {
            display: none;
        }
        
        /* Crop Modal */
        .crop-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            z-index: 1000;
        }
        
        .crop-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 20px;
            border-radius: 12px;
            max-width: 600px;
            width: 90%;
        }
        
        .crop-area {
            position: relative;
            width: 300px;
            height: 300px;
            border: 2px solid #7e1516;
            border-radius: 50%;
            margin: 20px auto;
            overflow: hidden;
            background: #f5f5f5;
            cursor: pointer;
        }
        
        .crop-area:hover {
            background: #e8e8e8;
        }
        
        .crop-image {
            position: absolute;
            cursor: move;
            user-select: none;
        }
        
        .select-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: #666;
            font-size: 16px;
            pointer-events: none;
        }
        
        .zoom-controls {
            display: none;
            text-align: center;
            margin: 15px 0;
        }
        
        .zoom-btn {
            background: #7e1516;
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            font-size: 18px;
            cursor: pointer;
            margin: 0 10px;
        }
        
        .zoom-btn:hover {
            background: #6a1214;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <a href="student_homepage.php" class="back-btn">Back to Dashboard</a>
            <h1>My Profile</h1>
        </div>
    </header>

    <main class="main-container">
        <?php if ($success_message): ?>
            <div class="message success"><?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
            <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>

        <div class="profile-card">
            <div class="profile-header">
                <form id="pictureForm" method="POST" enctype="multipart/form-data" style="display: inline-block;">
                    <div class="profile-avatar" onclick="openCropModal()">
                        <?php if ($profile_picture && file_exists(__DIR__ . '/' . $profile_picture)): ?>
                            <img src="<?php echo htmlspecialchars($profile_picture); ?>" alt="Profile Picture">
                        <?php else: ?>
                            <div class="default-avatar">👤</div>
                        <?php endif; ?>
                        <div class="upload-overlay">Click to change</div>
                    </div>
                </form>
                
                <div class="profile-info">
                    <h2><?php echo htmlspecialchars($student_data['full_name'] ?? 'Student'); ?></h2>
                    <p class="student-id">Student ID: <?php echo htmlspecialchars($student_id); ?></p>
                </div>
            </div>

            <div class="profile-content">
                <div class="info-section">
                    <div class="section-header">
                        <h3 class="section-title">Personal Information</h3>
                        <button class="settings-btn" onclick="toggleEdit()">⚙️</button>
                    </div>
                    
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Full Name</div>
                            <div class="info-value"><?php echo htmlspecialchars($student_data['full_name'] ?? 'N/A'); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Email Address</div>
                            <div class="info-value"><?php echo htmlspecialchars($student_data['email'] ?? 'N/A'); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Course</div>
                            <div class="info-value"><?php echo htmlspecialchars($student_data['course'] ?? 'N/A'); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Year Level</div>
                            <div class="info-value"><?php echo htmlspecialchars($student_data['year_level'] ?? 'N/A'); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Registration Date</div>
                            <div class="info-value"><?php echo date('F j, Y', strtotime($student_data['registration_date'] ?? '')); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Account Status</div>
                            <div class="info-value">Active</div>
                        </div>
                    </div>
                    
                    <div class="edit-form <?php echo $show_edit ? 'show' : ''; ?>" id="editForm">
                        <h4 style="margin-bottom: 20px; color: #374151;">Edit Profile Information</h4>
                        <form method="POST">
                            <input type="hidden" name="update_profile" value="1">
                            
                            <div class="form-group">
                                <label for="full_name">Full Name</label>
                                <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($student_data['full_name'] ?? ''); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($student_data['email'] ?? ''); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="course">Course</label>
                                <select id="course" name="course" required>
                                    <option value="">Select Course</option>
                                    <option value="BSIT" <?php echo ($student_data['course'] ?? '') == 'BSIT' ? 'selected' : ''; ?>>BS Information Technology</option>
                                    <option value="BSCS" <?php echo ($student_data['course'] ?? '') == 'BSCS' ? 'selected' : ''; ?>>BS Computer Science</option>
                                    <option value="BSIS" <?php echo ($student_data['course'] ?? '') == 'BSIS' ? 'selected' : ''; ?>>BS Information Systems</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="year_level">Year Level</label>
                                <select id="year_level" name="year_level" required>
                                    <option value="">Select Year Level</option>
                                    <option value="1" <?php echo ($student_data['year_level'] ?? '') == '1' ? 'selected' : ''; ?>>1st Year</option>
                                    <option value="2" <?php echo ($student_data['year_level'] ?? '') == '2' ? 'selected' : ''; ?>>2nd Year</option>
                                    <option value="3" <?php echo ($student_data['year_level'] ?? '') == '3' ? 'selected' : ''; ?>>3rd Year</option>
                                    <option value="4" <?php echo ($student_data['year_level'] ?? '') == '4' ? 'selected' : ''; ?>>4th Year</option>
                                </select>
                            </div>

                            <div class="btn-group">
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                                <button type="button" style="background-color:#7c1f1f" class="btn btn-secondary" onclick="toggleEdit()">Cancel</button>
                                <button type="button" class="btn btn-secondary" onclick="showPasswordForm()">Change Password</button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- Password Change Form -->
                    <div class="edit-form" id="passwordForm">
                        <h4 style="margin-bottom: 20px; color: #374151;">Change Password</h4>
                        <form method="POST">
                            <input type="hidden" name="change_password" value="1">
                            
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" id="new_password" name="new_password" required>
                            </div>

                            <div class="form-group">
                                <label for="confirm_password">Confirm Password</label>
                                <input type="password" id="confirm_password" name="confirm_password" required>
                            </div>

                            <div class="btn-group">
                                <button type="submit" class="btn btn-primary">Change Password</button>
                                <button type="button" style="background-color:#7c1f1f" class="btn btn-secondary" onclick="hidePasswordForm()">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Crop Modal -->
    <div class="crop-modal" id="cropModal">
        <div class="crop-container">
            <h3 style="text-align: center; margin-bottom: 20px;">Upload Profile Picture</h3>
            
            <input type="file" id="imageInput" accept="image/*" style="display: none;">
            
            <div class="crop-area" id="cropArea" onclick="document.getElementById('imageInput').click()">
                <img id="cropImage" class="crop-image" style="display: none;">
                <div class="select-text" id="selectText">Select Image</div>
            </div>
            
            <div class="zoom-controls" id="zoomControls">
                <button type="button" class="zoom-btn" onclick="zoomOut()">-</button>
                <button type="button" class="zoom-btn" onclick="zoomIn()">+</button>
            </div>
            
            <div class="crop-controls">
                <button type="button" onclick="cropAndUpload()" class="btn btn-primary" id="uploadBtn" style="display: none;">Save</button>
                <button type="button" onclick="closeCropModal()" class="btn btn-secondary">Cancel</button>
            </div>
        </div>
    </div>

    <script>
        let isDragging = false;
        let startX, startY, imageX = 0, imageY = 0;
        let currentScale = 1;
        
        function openCropModal() {
            document.getElementById('cropModal').style.display = 'block';
        }
        
        function closeCropModal() {
            document.getElementById('cropModal').style.display = 'none';
            document.getElementById('imageInput').value = '';
            document.getElementById('cropImage').style.display = 'none';
            document.getElementById('selectText').style.display = 'block';
            document.getElementById('uploadBtn').style.display = 'none';
            document.getElementById('zoomControls').style.display = 'none';
            document.getElementById('cropArea').onclick = function() { document.getElementById('imageInput').click(); };
            imageX = 0;
            imageY = 0;
            currentScale = 1;
        }
        
        function zoomIn() {
            currentScale = Math.min(currentScale * 1.2, 3);
            updateImageScale();
        }
        
        function zoomOut() {
            currentScale = Math.max(currentScale / 1.2, 0.5);
            updateImageScale();
        }
        
        function updateImageScale() {
            const img = document.getElementById('cropImage');
            if (img.style.display !== 'none') {
                const baseScale = Math.max(300 / img.naturalWidth, 300 / img.naturalHeight);
                const newWidth = img.naturalWidth * baseScale * currentScale;
                const newHeight = img.naturalHeight * baseScale * currentScale;
                
                img.style.width = newWidth + 'px';
                img.style.height = newHeight + 'px';
                
                // Adjust position to keep image centered when zooming
                const centerX = 150 - (newWidth / 2);
                const centerY = 150 - (newHeight / 2);
                imageX = centerX;
                imageY = centerY;
                img.style.left = imageX + 'px';
                img.style.top = imageY + 'px';
            }
        }
        
        document.getElementById('imageInput').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const img = document.getElementById('cropImage');
                    img.src = e.target.result;
                    img.style.display = 'block';
                    document.getElementById('selectText').style.display = 'none';
                    document.getElementById('uploadBtn').style.display = 'inline-block';
                    document.getElementById('zoomControls').style.display = 'block';
                    document.getElementById('cropArea').onclick = null;
                    currentScale = 1;
                    
                    // Center image initially
                    img.onload = function() {
                        const scale = Math.max(300 / img.naturalWidth, 300 / img.naturalHeight);
                        img.style.width = (img.naturalWidth * scale) + 'px';
                        img.style.height = (img.naturalHeight * scale) + 'px';
                        
                        imageX = (300 - img.offsetWidth) / 2;
                        imageY = (300 - img.offsetHeight) / 2;
                        img.style.left = imageX + 'px';
                        img.style.top = imageY + 'px';
                    };
                };
                reader.readAsDataURL(file);
            }
        });
        
        // Drag functionality for desktop
        document.getElementById('cropImage').addEventListener('mousedown', function(e) {
            isDragging = true;
            startX = e.clientX - imageX;
            startY = e.clientY - imageY;
            e.preventDefault();
        });
        
        document.addEventListener('mousemove', function(e) {
            if (isDragging) {
                imageX = e.clientX - startX;
                imageY = e.clientY - startY;
                
                const img = document.getElementById('cropImage');
                img.style.left = imageX + 'px';
                img.style.top = imageY + 'px';
            }
        });
        
        document.addEventListener('mouseup', function() {
            isDragging = false;
        });
        
        // Touch functionality for mobile
        document.getElementById('cropImage').addEventListener('touchstart', function(e) {
            isDragging = true;
            const touch = e.touches[0];
            startX = touch.clientX - imageX;
            startY = touch.clientY - imageY;
            e.preventDefault();
        });
        
        document.addEventListener('touchmove', function(e) {
            if (isDragging) {
                const touch = e.touches[0];
                imageX = touch.clientX - startX;
                imageY = touch.clientY - startY;
                
                const img = document.getElementById('cropImage');
                img.style.left = imageX + 'px';
                img.style.top = imageY + 'px';
                e.preventDefault();
            }
        });
        
        document.addEventListener('touchend', function() {
            isDragging = false;
        });
        
        function cropAndUpload() {
            const img = document.getElementById('cropImage');
            
            if (img.style.display === 'none') {
                alert('Please select an image first');
                return;
            }
            
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = 200;
            canvas.height = 200;
            
            // Calculate crop area (300x300 circle to 200x200 output)
            const sourceX = -imageX / (img.offsetWidth / img.naturalWidth);
            const sourceY = -imageY / (img.offsetHeight / img.naturalHeight);
            const sourceSize = 300 / (img.offsetWidth / img.naturalWidth);
            
            ctx.drawImage(img, sourceX, sourceY, sourceSize, sourceSize, 0, 0, 200, 200);
            
            canvas.toBlob(function(blob) {
                const formData = new FormData();
                formData.append('profile_picture', blob, 'profile.png');
                
                fetch('student_profile_new.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(data => {
                    closeCropModal();
                    location.reload();
                })
                .catch(error => {
                    alert('Upload failed. Please try again.');
                });
            }, 'image/png');
        }
        
        function toggleEdit() {
            const form = document.getElementById('editForm');
            form.classList.toggle('show');
        }
        
        function showPasswordForm() {
            document.getElementById('editForm').classList.remove('show');
            document.getElementById('passwordForm').classList.add('show');
        }
        
        function hidePasswordForm() {
            document.getElementById('passwordForm').classList.remove('show');
        }
        
        <?php if ($show_edit): ?>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('editForm').classList.add('show');
        });
        <?php endif; ?>
    </script>
</body>
</html>