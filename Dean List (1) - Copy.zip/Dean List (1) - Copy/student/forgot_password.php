<?php
session_start();
require_once '../config/database.php';
require_once '../config/password_reset_email.php';

function asset($file) {
    $base = dirname($_SERVER['SCRIPT_NAME']);
    if ($base === '/' || $base === '\\' || $base === '.') {
        $base = '';
    }
    return ($base === '' ? '' : rtrim($base, '/')) . '/' . ltrim($file, '/');
}

$message = '';
$step = 1; // 1: Enter email, 2: Check email message, 3: Reset password

if (isset($_GET['token']) && isset($_GET['email'])) {
    $database = new Database();
    $db = $database->getConnection();
    
    try {
        $query = "SELECT * FROM password_resets WHERE email = ? AND token = ? AND expires_at > NOW()";
        $stmt = $db->prepare($query);
        $stmt->execute([$_GET['email'], $_GET['token']]);
        
        if ($stmt->rowCount() > 0) {
            $_SESSION['reset_email'] = $_GET['email'];
            $_SESSION['reset_verified'] = true;
            $step = 3;
        } else {
            $message = "Invalid or expired reset link.";
        }
    } catch (Exception $e) {
        $message = "Error verifying reset link.";
    }
}

if (isset($_SESSION['reset_verified']) && $_SESSION['reset_verified'] === true) {
    $step = 3;
} elseif (isset($_SESSION['email_sent'])) {
    $step = 2;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = new Database();
    $db = $database->getConnection();
    
    if (isset($_POST['send_reset'])) {
        $email = $_POST['email'] ?? '';
        
        if (!empty($email)) {
            try {
                $query = "SELECT u.student_id, s.full_name FROM users u 
                         JOIN students s ON u.student_id = s.student_id 
                         WHERE u.email = ? AND u.role = 'student'";
                $stmt = $db->prepare($query);
                $stmt->execute([$email]);
                
                if ($stmt->rowCount() > 0) {
                    $user = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    $reset_token = bin2hex(random_bytes(32));
                    $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));
                    
                    $insert_token = "INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)
                                   ON DUPLICATE KEY UPDATE token = VALUES(token), expires_at = VALUES(expires_at)";
                    $stmt = $db->prepare($insert_token);
                    $stmt->execute([$email, $reset_token, $expires_at]);
                    
                    // Send password reset email
                    $passwordResetEmail = new PasswordResetEmail();
                    $passwordResetEmail->sendPasswordResetEmail($email, '123456', $user['full_name'], $reset_token);
                    
                    $_SESSION['email_sent'] = true;
                    $_SESSION['reset_email'] = $email;
                    $step = 2;
                } else {
                    $message = "Email address not found.";
                }
            } catch (Exception $e) {
                $message = "Error processing request.";
            }
        } else {
            $message = "Please enter your email address.";
        }
    }
    
    if (isset($_POST['reset_password'])) {
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $email = $_SESSION['reset_email'] ?? '';
        
        if (!empty($new_password) && !empty($confirm_password) && !empty($email)) {
            if ($new_password === $confirm_password) {
                try {
                    $update_query = "UPDATE users SET password = ? WHERE email = ? AND role = 'student'";
                    $stmt = $db->prepare($update_query);
                    $stmt->execute([$new_password, $email]);
                    
                    $delete_token = "DELETE FROM password_resets WHERE email = ?";
                    $stmt = $db->prepare($delete_token);
                    $stmt->execute([$email]);
                    
                    unset($_SESSION['reset_email']);
                    unset($_SESSION['reset_verified']);
                    unset($_SESSION['email_sent']);
                    
                    $_SESSION['success_message'] = "Password changed successfully! You can now login.";
                    header('Location: student_login.php');
                    exit();
                } catch (Exception $e) {
                    $message = "Error updating password.";
                }
            } else {
                $message = "Passwords do not match!";
            }
        } else {
            $message = "Please fill in all fields.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Dean's List</title>
    <link rel="stylesheet" href="<?php echo asset('../login.css'); ?>">
</head>
<body>
    <div class="background-blur"></div>

    <header>
        <img src="<?php echo asset('../resource/logo.png'); ?>" alt="LSPU Logo" class="logo">
        <h1>DEAN'S LIST APPLICATION</h1>
    </header>

    <main style="display:flex; justify-content:center; padding-top:40px;">
        <section class="portal student-login" style="max-width:420px; width:100%;">
            <div class="icon">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 2L1 7l11 5 9-4.09V17a2 2 0 0 1-2 2h-1" stroke="#2b6cb0" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M12 22v-7" stroke="#2b6cb0" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            
            <?php if ($step == 1): ?>
                <h2>Forgot Password</h2>
                <p>Enter your email to reset password</p>
                
                <?php if (!empty($message)): ?>
                    <div style="color:#fff;background:#ef4444;padding:10px;border-radius:8px;margin:10px 0;">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>
                
                <form method="post" action="">
                    <label for="email">Email Address</label>
                    <input id="email" name="email" type="email" placeholder="your.email@example.com" 
                           style="display:block; width:100%; padding:12px; margin:10px 0 18px; border-radius:8px; border:1px solid #eee; background:#f7f7f8;" required>
                    <button type="submit" name="send_reset" class="btn student-btn">Send Reset Instructions</button>
                </form>
                
            <?php elseif ($step == 2): ?>
                <h2>Check Your Email</h2>
                <p>Password reset instructions sent!</p>
                
                <div style="text-align:center; margin:20px 0;">
                    <p style="color:#10b981; font-weight:bold;">📧 Email Sent!</p>
                    <p style="font-size:14px; color:#666;">We've sent password reset instructions to:<br><strong><?php echo htmlspecialchars($_SESSION['reset_email'] ?? ''); ?></strong></p>
                    <p style="font-size:14px; color:#666; margin-top:15px;">Check your inbox and spam folder for the reset link.</p>
                    <p style="font-size:12px; color:#999; margin-top:10px;">The link will expire in 1 hour.</p>
                </div>
                
            <?php else: ?>
                <h2>Reset Password</h2>
                <p>Enter your new password</p>
                
                <?php if (!empty($message)): ?>
                    <div style="color:#fff;background:<?php echo strpos($message, 'successful') !== false ? '#10b981' : '#ef4444'; ?>;padding:10px;border-radius:8px;margin:10px 0;">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>
                
                <form method="post" action="">
                    <label for="new_password">New Password</label>
                    <input id="new_password" name="new_password" type="password" 
                           style="display:block; width:100%; padding:12px; margin:10px 0 18px; border-radius:8px; border:1px solid #eee; background:#f7f7f8;" required>

                    <label for="confirm_password">Confirm Password</label>
                    <input id="confirm_password" name="confirm_password" type="password" 
                           style="display:block; width:100%; padding:12px; margin:10px 0 18px; border-radius:8px; border:1px solid #eee; background:#f7f7f8;" required>

                    <button type="submit" name="reset_password" class="btn student-btn">Change Password</button>
                </form>
            <?php endif; ?>

            <div style="text-align:center; margin-top:1rem;">
                <a href="student_login.php" style="color:#4a5568; text-decoration:none;">
                    Back to Login
                </a>
            </div>
        </section>
    </main>
</body>
</html>