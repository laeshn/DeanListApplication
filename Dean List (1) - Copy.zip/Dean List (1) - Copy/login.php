<?php
session_start();
require_once 'config/database.php';

function asset($file) {
    $base = dirname($_SERVER['SCRIPT_NAME']);
    if ($base === '/' || $base === '\\' || $base === '.') {
        $base = '';
    }
    return ($base === '' ? '' : rtrim($base, '/')) . '/' . ltrim($file, '/');
}

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = new Database();
    $db = $database->getConnection();
    
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (!empty($email) && !empty($password)) {
        $query = "SELECT u.*, sp.student_id, sp.full_name 
                 FROM users u 
                 LEFT JOIN student_profiles sp ON u.id = sp.user_id 
                 WHERE u.email = :email";
        $stmt = $db->prepare($query);
        $stmt->bindParam(":email", $email);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($password == $user['password']) { // In production, use password_verify()
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];
                
                if ($user['role'] == 'student') {
                    $_SESSION['student_id'] = $user['student_id'];
                    $_SESSION['full_name'] = $user['full_name'];
                    header("Location: student/student_homepage.php");
                } else {
                    header("Location: admin/admin_homepage.php");
                }
                exit();
            } else {
                $error_message = "Invalid password";
            }
        } else {
            // No user found - offer registration
            $_SESSION['register_email'] = $email;
            header("Location: register.php");
            exit();
        }
    } else {
        $error_message = " both email and password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dean's List Application System</title>
  <link rel="stylesheet" href="<?php echo asset('login.css'); ?>" />
  <style>
    .about-section { text-align: center; margin-top: 5px; padding: 10px; }
    .about-link { color: #fff; text-decoration: underline; cursor: pointer; font-size: 16px; }
    .about-link:hover { color: #d0d2d5ff; }
    .modal-overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 1000; justify-content: center; align-items: center; }
    .modal-overlay.active { display: flex; }
    .modal-content { background: white; padding: 40px; border-radius: 12px; max-width: 500px; width: 90%; box-shadow: 0 10px 40px rgba(0,0,0,0.3); }
    .modal-content h2 { margin: 0 0 20px 0; color: #2b6cb0; }
    .modal-content p { margin: 10px 0; line-height: 1.6; color: #333; }
    .modal-content .developers { margin-top: 20px; padding: 15px; background: #f8fafc; border-radius: 8px; }
    .modal-content .developers h3 { margin: 0 0 10px 0; color: #6b46c1; font-size: 16px; }
    .modal-content .developers p { margin: 5px 0; font-weight: 600; color: #2b6cb0; }
    .modal-content .class-info { margin-top: 10px; font-style: italic; color: #6b7280; }
    .close-modal { background: #2b6cb0; color: white; border: none; padding: 10px 24px; border-radius: 6px; cursor: pointer; margin-top: 20px; font-weight: 600; }
    .close-modal:hover { background: #1e4d7b; }
    
    @media (max-width: 768px) {
      .about-link { font-size: 14px; }
      .modal-content { padding: 30px 20px; max-width: 90%; }
      .modal-content h2 { font-size: 20px; }
      .modal-content p { font-size: 14px; }
      .modal-content .developers h3 { font-size: 15px; }
      .modal-content .developers p { font-size: 14px; }
    }
    
    @media (max-width: 480px) {
      .about-section { margin-top: 0; padding: 8px; }
      .about-link { font-size: 13px; }
      .modal-content { padding: 24px 16px; }
      .modal-content h2 { font-size: 18px; margin-bottom: 15px; }
      .modal-content p { font-size: 13px; line-height: 1.5; }
      .modal-content .developers { padding: 12px; }
      .modal-content .developers h3 { font-size: 14px; }
      .modal-content .developers p { font-size: 13px; }
      .close-modal { padding: 9px 20px; font-size: 14px; }
    }
  </style>
</head>
<body>
  <div class="background-blur"></div>

  <header>
    <div class="logos" style="display: inline;">
      <img src="<?php echo asset('resource/logo.png'); ?>" alt="LSPU Logo" class="logo" />
      <img src="<?php echo asset('resource/ccs_logo.png'); ?>" alt="CCS Logo" class="logo" />
      
    </div>
    <h1>Dean's List Application System</h1>
    <p class="subtitle">College of Computer Studies</p>
  </header>

  <main class="portal-container">
    <section class="portal student">
      <div class="icon">
        <!-- student graduation cap icon -->
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path d="M12 2L1 7l11 5 9-4.09V17a2 2 0 0 1-2 2h-1" stroke="#2b6cb0" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M12 22v-7" stroke="#2b6cb0" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </div>
      <h2>Student Portal</h2>
      <p>Log-in to your LSPU Account</p>
      <a href="<?php echo asset('student/student_login.php'); ?>" class="btn student-btn">Enter Student Portal</a>
    </section>

    <section class="portal admin">
      <div class="icon">
        <!-- admin shield icon -->
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path d="M12 2l7 3v5c0 5-3.58 9.74-7 11-3.42-1.26-7-6-7-11V5l7-3z" stroke="#6b46c1" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </div>
      <h2>Admin Portal</h2>
      <p>Log-in to your LSPU Account</p>
      <a href="<?php echo asset('admin/admin_login.php'); ?>" class="btn admin-btn">Enter Admin Portal</a>
    </section>
  </main>

  <div class="about-section">
    <span class="about-link" onclick="openAboutModal()">Learn more about us</span>
  </div>

  <div class="modal-overlay" id="aboutModal" onclick="closeAboutModal()">
    <div class="modal-content" onclick="event.stopPropagation()">
      <h2>About the System</h2>
      <p>The <strong>Dean's List Application System</strong> is a comprehensive web-based platform designed to streamline the process of managing and tracking academic excellence at Laguna State Polytechnic University - College of Computer Studies.</p>
      <p>This system allows students to submit their applications for Dean's List recognition, enables administrators to review and manage applications efficiently, and provides automated ranking based on academic performance.</p>
      <div class="developers">
        <h3>Developed by:</h3>
        <p>Czamantta Althea Salinas</p>
        <p>Lovely Helaenah Teodoro</p>
        <p class="class-info">BSIT 3A WMAD</p>
      </div>
      <button class="close-modal" onclick="closeAboutModal()">Close</button>
    </div>
  </div>

  <script>
    function openAboutModal() {
      document.getElementById('aboutModal').classList.add('active');
    }
    function closeAboutModal() {
      document.getElementById('aboutModal').classList.remove('active');
    }
  </script>
</body>
</html>