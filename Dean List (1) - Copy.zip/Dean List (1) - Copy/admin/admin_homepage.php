<?php
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../config/database.php';

// Asset helper (keeps your existing helper)
function asset($file) {
    $base = dirname($_SERVER['SCRIPT_NAME']);
    if ($base === '/' || $base === '\\' || $base === '.') {
        $base = '';
    }
    return ($base === '' ? '' : rtrim($base, '/')) . '/' . ltrim($file, '/');
}

// Admin-only guard
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

try {
    $db = (new Database())->getConnection();
    // enforce consistent connection charset/collation to avoid mixed collation errors
    $db->exec("SET NAMES 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'");
} catch (Throwable $e) {
    error_log("[admin_homepage] DB connect error: " . $e->getMessage());
    echo "Database connection error";
    exit();
}

// Get current application status
$appStatus = 'unknown';
try {
    $statusQuery = "SELECT status FROM application_status ORDER BY id DESC LIMIT 1";
    $statusStmt = $db->prepare($statusQuery);
    $statusStmt->execute();
    $statusData = $statusStmt->fetch(PDO::FETCH_ASSOC);
    if ($statusData) {
        $appStatus = $statusData['status'];
    }
} catch (Exception $e) {
    // Keep default value
}

// Get current semester and academic year info
$currentSemester = 'No Active Semester';
$currentAcadYear = 'Not Set';
try {
    $semQuery = "SELECT cs.semester_number, ay.academic_year 
                 FROM current_semester cs 
                 LEFT JOIN semester s ON 1=1 
                 LEFT JOIN acad_year ay ON ay.acadID = s.acadID 
                 ORDER BY cs.id DESC LIMIT 1";
    $semStmt = $db->prepare($semQuery);
    $semStmt->execute();
    $semData = $semStmt->fetch(PDO::FETCH_ASSOC);
    if ($semData) {
        $semNum = $semData['semester_number'];
        $currentSemester = ($semNum == '1' ? '1st' : '2nd') . ' Semester';
        $currentAcadYear = $semData['academic_year'] ?? 'Not Set';
    }
} catch (Exception $e) {
    // Keep defaults
}

// Auto-expire semesters based on end_date
try {
    $expiredStmt = $db->prepare("SELECT semID, acadID FROM semester WHERE end_date < CURDATE() AND semID IN (SELECT semID FROM current_semester)");
    $expiredStmt->execute();
    $expiredSem = $expiredStmt->fetch();
    
    if ($expiredSem) {
        require_once __DIR__ . '/../shared/archive_rankings.php';
        archiveRankings();
        $db->exec("DELETE FROM current_semester");
    }
} catch (Exception $e) {
    error_log("Auto-expire check error: " . $e->getMessage());
}

// Create activity_log table if not exists
try {
    $db->exec("CREATE TABLE IF NOT EXISTS activity_log (
        id INT AUTO_INCREMENT PRIMARY KEY,
        activity_type ENUM('semester_opened', 'semester_closed', 'applications_opened', 'applications_closed', 'rankings_generated', 'rankings_archived') NOT NULL,
        description TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_created_at (created_at DESC)
    )");
} catch (Exception $e) {
    error_log("Activity log table creation error: " . $e->getMessage());
}

// Handle form submissions
$message = $_GET['msg'] ?? '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['action'] == 'set_semester') {
        $academic_year = $_POST['academic_year'];
        $semester_num = $_POST['semester_number'];
        $start_date = $_POST['start_date'];
        $end_date = $_POST['end_date'];
        
        try {
            // Add academic_year column if it doesn't exist
            $checkCol = $db->query("SHOW COLUMNS FROM acad_year LIKE 'academic_year'");
            if ($checkCol->rowCount() == 0) {
                $db->exec("ALTER TABLE acad_year ADD COLUMN academic_year VARCHAR(20) AFTER acadID");
            }
            
            // Check for existing active semester
            $activeStmt = $db->prepare("SELECT COUNT(*) FROM current_semester");
            $activeStmt->execute();
            $hasActiveSemester = $activeStmt->fetchColumn() > 0;
            
            if ($hasActiveSemester) {
                $message = "WARN_ACTIVE_SEMESTER";
            } else {
                // Check if academic year exists
                $checkAcadStmt = $db->prepare("SELECT acadID FROM acad_year WHERE academic_year = ?");
                $checkAcadStmt->execute([$academic_year]);
                $acadData = $checkAcadStmt->fetch();
                
                if (!$acadData) {
                    // Insert new academic year
                    $stmt = $db->prepare("INSERT INTO acad_year (academic_year, start_date, end_date) VALUES (?, ?, ?)");
                    $stmt->execute([$academic_year, $start_date, $end_date]);
                    $acadID = $db->lastInsertId();
                } else {
                    $acadID = $acadData['acadID'];
                }
                
                // Insert new semester
                $stmt = $db->prepare("INSERT INTO semester (semester_name, acadID) VALUES (?, ?)");
                $semesterName = ($semester_num == '1' ? '1st' : '2nd') . ' Semester';
                $stmt->execute([$semesterName, $acadID]);
                
                // Update current_semester
                $stmt = $db->prepare("INSERT INTO current_semester (semester_number) VALUES (?)");
                $stmt->execute([$semester_num]);
                
                $currentSemester = ($semester_num == '1' ? '1st' : '2nd') . ' Semester';
                $message = "Set {$currentSemester} for Academic Year {$academic_year}";
                
                // Log activity
                $logStmt = $db->prepare("INSERT INTO activity_log (activity_type, description) VALUES ('semester_opened', ?)");
                $logStmt->execute(["Opened {$currentSemester} for Academic Year {$academic_year} (Start: {$start_date}, End: {$end_date})"]);
            }
        } catch (Exception $e) {
            $message = "Error setting semester: " . $e->getMessage();
        }
    }
    
    if ($_POST['action'] == 'end_semester') {
        try {
            require_once __DIR__ . '/../shared/archive_rankings.php';
            $archiveResult = archiveRankings();
            
            if ($archiveResult['success']) {
                // Clear current_semester table
                $db->exec("DELETE FROM current_semester");
                $currentSemester = 'No Active Semester';
                $message = "Semester ended successfully! " . $archiveResult['archived_count'] . " rankings archived";
                
                // Log activity
                $logStmt = $db->prepare("INSERT INTO activity_log (activity_type, description) VALUES ('semester_closed', ?)");
                $logStmt->execute(["Semester ended - {$archiveResult['archived_count']} rankings archived"]);
            } else {
                $message = "Error ending semester: " . $archiveResult['message'];
            }
        } catch (Exception $e) {
            $message = "Error ending semester: " . $e->getMessage();
        }
    }
    
    if ($_POST['action'] == 'toggle_applications') {
        $app_status = $_POST['app_status'];
        
        try {
            // Create application_status table
            $db->exec("CREATE TABLE IF NOT EXISTS application_status (
                id INT AUTO_INCREMENT PRIMARY KEY,
                status ENUM('open', 'closed') NOT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )");
            
            if ($app_status == 'open') {
                $message = "Applications manually opened";
                
                // Log activity
                $logStmt = $db->prepare("INSERT INTO activity_log (activity_type, description) VALUES ('applications_opened', 'Applications opened for student submissions')");
                $logStmt->execute();
            } else {
                $message = "Applications manually closed";
                
                // Log activity
                $logStmt = $db->prepare("INSERT INTO activity_log (activity_type, description) VALUES ('applications_closed', 'Applications closed - no longer accepting submissions')");
                $logStmt->execute();
                
                // If closing applications, generate rankings automatically
                try {
                    require_once __DIR__ . '/../shared/generate_rankings.php';
                    $rankingResult = generateRankings();
                    if ($rankingResult['success']) {
                        $message .= " and rankings generated (" . $rankingResult['total_ranked'] . " students ranked)";
                        
                        // Log ranking generation
                        $logStmt = $db->prepare("INSERT INTO activity_log (activity_type, description) VALUES ('rankings_generated', ?)");
                        $logStmt->execute(["Rankings generated - {$rankingResult['total_ranked']} students ranked"]);
                    } else {
                        $message .= " but ranking generation failed: " . $rankingResult['message'];
                    }
                } catch (Exception $rankingError) {
                    $message .= " but ranking generation failed: " . $rankingError->getMessage();
                }
            }
            
            // Clear existing status and insert new one
            $db->exec("DELETE FROM application_status");
            $stmt = $db->prepare("INSERT INTO application_status (status) VALUES (?)");
            $stmt->execute([$app_status]);
            
        } catch (Exception $e) {
            $message = "Error toggling applications: " . $e->getMessage();
        }
        
        // Redirect to prevent form resubmission
        header('Location: ' . $_SERVER['PHP_SELF'] . '?msg=' . urlencode($message));
        exit();
    }
    
    if ($_POST['action'] == 'clear_logs') {
        try {
            $db->exec("DELETE FROM activity_log");
            $message = "Activity logs cleared successfully";
        } catch (Exception $e) {
            $message = "Error clearing logs: " . $e->getMessage();
        }
        
        // Redirect to prevent form resubmission
        header('Location: ' . $_SERVER['PHP_SELF'] . '?msg=' . urlencode($message));
        exit();
    }
}

// --------- Dashboard metrics (matching your DB) ---------
// Total applications for current semester
try {
    $stmt = $db->prepare("
        SELECT COUNT(*) FROM applications a
        LEFT JOIN semester s ON s.semID = a.semID
        LEFT JOIN current_semester cs ON 1=1
        WHERE (SELECT COUNT(*) FROM current_semester) > 0
    ");
    $stmt->execute();
    $totalApplications = (int)$stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("[admin_homepage] totalApplications: " . $e->getMessage());
    $totalApplications = 0;
}

// Under review
try {
    $stmt = $db->prepare("SELECT COUNT(*) FROM applications WHERE status = 'under-review'");
    $stmt->execute();
    $underReview = (int)$stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("[admin_homepage] underReview: " . $e->getMessage());
    $underReview = 0;
}

// Approved
try {
    $stmt = $db->prepare("SELECT COUNT(*) FROM applications WHERE status = 'accepted'");
    $stmt->execute();
    $approved = (int)$stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("[admin_homepage] approved: " . $e->getMessage());
    $approved = 0;
}

// Rejected
try {
    $stmt = $db->prepare("SELECT COUNT(*) FROM applications WHERE status = 'rejected'");
    $stmt->execute();
    $rejected = (int)$stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("[admin_homepage] rejected: " . $e->getMessage());
    $rejected = 0;
}

// Active students separated by course
$studentsByCourse = [];
try {
    $stmt = $db->prepare("
        SELECT course, COUNT(*) as count 
        FROM students 
        WHERE course IS NOT NULL AND course != '' 
        GROUP BY course 
        ORDER BY course
    ");
    $stmt->execute();
    $studentsByCourse = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Total active students
    $stmt = $db->prepare("SELECT COUNT(*) FROM students");
    $stmt->execute();
    $activeStudents = (int)$stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("[admin_homepage] activeStudents: " . $e->getMessage());
    $activeStudents = 0;
    $studentsByCourse = [];
}

// Approval rate (guard divide by zero)
$approvalRate = $totalApplications > 0 ? round(($approved / $totalApplications) * 100, 1) : 0;

// ---------- Quick actions ----------
// Pending reviews
$pendingReviews = $underReview;

// Overdue decisions: under-review older than threshold (days)
$overdueDays = 14;
try {
    $stmt = $db->prepare("SELECT COUNT(*) FROM applications WHERE status = 'under-review' AND created_at < (NOW() - INTERVAL :days DAY)");
    $stmt->execute([':days' => $overdueDays]);
    $overdueDecisions = (int)$stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("[admin_homepage] overdueDecisions: " . $e->getMessage());
    $overdueDecisions = 0;
}

// Today's Priority: under-review applications created today
try {
    $stmt = $db->prepare("SELECT COUNT(*) FROM applications WHERE status = 'under-review' AND DATE(created_at) = CURDATE()");
    $stmt->execute();
    $todaysPriority = (int)$stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("[admin_homepage] todaysPriority: " . $e->getMessage());
    $todaysPriority = 0;
}

// ---------- Semester trend data for chart ----------
$chartLabels = [];
$chartData = [];
try {
    $stmt = $db->prepare("
        SELECT 
            a.semID,
            a.acadID,
            COUNT(*) AS cnt,
            MAX(a.created_at) AS last_at
        FROM applications a
        WHERE a.semID IS NOT NULL AND a.acadID IS NOT NULL
        GROUP BY a.semID, a.acadID
        ORDER BY a.acadID ASC, a.semID ASC
        LIMIT 10
    ");
    $stmt->execute();
    $semRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($semRows as $row) {
        // Get academic year and semester for each group
        $labelStmt = $db->prepare("
            SELECT ay.academic_year, sem.semID
            FROM acad_year ay
            LEFT JOIN semester sem ON sem.acadID = ay.acadID
            WHERE ay.acadID = ? AND sem.semID = ?
            LIMIT 1
        ");
        $labelStmt->execute([$row['acadID'], $row['semID']]);
        $labelData = $labelStmt->fetch(PDO::FETCH_ASSOC);
        
        if ($labelData && $labelData['academic_year']) {
            // Determine semester number from semID (you may need to adjust this logic)
            $semNum = ($row['semID'] % 2 == 0) ? '2nd' : '1st';
            $chartLabels[] = $labelData['academic_year'] . ' - ' . $semNum . ' Sem';
        } else {
            $chartLabels[] = 'Semester ' . $row['semID'];
        }
        $chartData[] = (int)$row['cnt'];
    }
    
    // If no data, show empty chart
    if (empty($chartLabels)) {
        $chartLabels = ['No Data'];
        $chartData = [0];
    }
} catch (PDOException $e) {
    error_log("[admin_homepage] semester trends: " . $e->getMessage());
    $chartLabels = ['No Data'];
    $chartData = [0];
}

// Small helper for pretty numbers
function pretty_number($n) {
    return number_format((int)$n);
}

?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Admin Dashboard - Dean's List</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <!-- linked to the merged/edited admin.css -->
  <link rel="stylesheet" href="<?php echo asset('../admin/admin.css'); ?>">
  <style>
    /* minimal page-specific overrides kept inline if needed */
    html, body { height: 100%; }
    /* ensure Chart canvas fills container */
    .chart-container { height: 320px; }
    @media (max-width:980px) {
      .stats-grid { grid-template-columns:repeat(2,1fr); }
      .dashboard-grid { grid-template-columns:1fr; }
    }
  </style>

  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
  <!-- Updated markup to use the merged admin.css canonical classes (centered nav) -->
  <nav class="admin-header" role="navigation" aria-label="Admin navigation">
    <div class="header-content">
      <div class="nav-brand">
        <h1 class="portal-title">Admin Portal</h1>
      </div>

      <div class="main-nav" role="menubar" aria-label="Main">
        <a role="menuitem" href="<?php echo asset('admin_homepage.php'); ?>" class="active">Home</a>
        <a role="menuitem" href="<?php echo asset('admin_applications.php'); ?>">Status</a>
        <a role="menuitem" href="<?php echo asset('../shared/rankings.php'); ?>">Rankings</a>
        <a role="menuitem" href="<?php echo asset('admin_users.php'); ?>">Manage Users</a>
        <a role="menuitem" href="<?php echo asset('admin_reports.php'); ?>">Reports</a>
      </div>

      <div class="user-nav" aria-label="User">
        <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Admin'); ?></span>
        <a href="<?php echo asset('admin_logout.php'); ?>">Logout</a>
      </div>
    </div>
  </nav>

  <main class="container page-container" role="main">
    <header class="page-header">
      <h2>Welcome back, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Admin'); ?></h2>
      <div style="margin: 8px 0; padding: 8px 12px; background: #f8fafc; border-radius: 6px; font-size: 14px; color: #64748b;">
        <strong>Current Period:</strong> <?php echo htmlspecialchars($currentSemester); ?> • Academic Year <?php echo htmlspecialchars($currentAcadYear); ?>
      </div>
      <?php if ($message && $message !== 'WARN_ACTIVE_SEMESTER'): ?>
        <div style="padding:12px; margin:12px 0; background:#10b981; color:white; border-radius:8px;">
          <?php echo htmlspecialchars($message); ?>
        </div>
      <?php endif; ?>
    </header>

    <div class="stats-grid" aria-hidden="false">
      <div class="card stat-card">
        <h4>Total Applications</h4>
        <div class="stat-value"><?php echo pretty_number($totalApplications); ?></div>
        <p class="stat-note">Current semester</p>
      </div>

      <div class="card stat-card">
        <h4>Under Review</h4>
        <div class="stat-value"><?php echo pretty_number($underReview); ?></div>
        <p class="stat-note">Require attention</p>
      </div>

      <div class="card stat-card">
        <h4>Approved</h4>
        <div class="stat-value"><?php echo pretty_number($approved); ?></div>
        <p class="stat-note"><?php echo htmlspecialchars($approvalRate . '%'); ?> approval rate</p>
      </div>

      <div class="card stat-card">
        <h4>Active Students</h4>
        <div class="stat-value"><?php echo pretty_number($activeStudents); ?></div>
        <p class="stat-note" title="<?php 
          if (count($studentsByCourse) > 0) {
            $allCourses = array_map(function($c) { return $c['course'] . ': ' . $c['count']; }, $studentsByCourse);
            echo htmlspecialchars(implode(' • ', $allCourses));
          } else {
            echo 'No course data available';
          }
        ?>" style="cursor: help;"><?php 
          if (count($studentsByCourse) > 0) {
            $courseList = array_map(function($c) { return $c['course'] . ': ' . $c['count']; }, array_slice($studentsByCourse, 0, 2));
            echo implode(' • ', $courseList);
            if (count($studentsByCourse) > 2) echo ' • Others';
          } else {
            echo 'Currently enrolled';
          }
        ?></p>
      </div>
    </div>

    <div class="dashboard-grid" style="margin-top: 26px;">
      <section class="card" style="background-color: white;">
        <h3 style="margin-top:0;">Semester Application</h3>
        <p class="subtitle">Application volume over recent semesters</p>
        <div class="chart-container">
          <canvas id="trendChart" aria-label="Semester application trends chart" role="img"></canvas>
        </div>
        
        <!-- Activity Log -->
        <div style="margin-top:24px; padding-top:20px; border-top:1px solid #e5e7eb;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
            <div>
              <h4 style="margin:0; font-size:16px; color:#111827;">Recent Activity</h4>
              <p style="font-size:13px; color:#6b7280; margin:4px 0 0 0;">Latest semester and application updates</p>
            </div>
            <form method="post" action="" style="display:inline;">
              <input type="hidden" name="action" value="clear_logs">
              <button type="submit" onclick="return confirm('Are you sure you want to clear all activity logs?')" 
                      style="padding:4px 8px; background:#ef4444; color:white; border:none; border-radius:4px; cursor:pointer; font-size:11px;">Clear Logs</button>
            </form>
          </div>
          <?php
          try {
              $logStmt = $db->prepare("SELECT activity_type, description, created_at FROM activity_log ORDER BY created_at DESC LIMIT 10");
              $logStmt->execute();
              $activities = $logStmt->fetchAll(PDO::FETCH_ASSOC);
              
              if (count($activities) > 0) {
                  echo '<div style="display:flex; flex-direction:column; gap:10px;">';
                  foreach ($activities as $activity) {
                      $iconColor = '#6b7280';
                      $bgColor = '#f3f4f6';
                      $icon = '●';
                      
                      switch ($activity['activity_type']) {
                          case 'semester_opened':
                              $iconColor = '#059669';
                              $bgColor = '#d1fae5';
                              $icon = '▶';
                              break;
                          case 'semester_closed':
                              $iconColor = '#dc2626';
                              $bgColor = '#fee2e2';
                              $icon = '■';
                              break;
                          case 'applications_opened':
                              $iconColor = '#2563eb';
                              $bgColor = '#dbeafe';
                              $icon = '✓';
                              break;
                          case 'applications_closed':
                              $iconColor = '#ea580c';
                              $bgColor = '#fed7aa';
                              $icon = '✕';
                              break;
                          case 'rankings_generated':
                              $iconColor = '#7c3aed';
                              $bgColor = '#ede9fe';
                              $icon = '★';
                              break;
                          case 'rankings_archived':
                              $iconColor = '#4b5563';
                              $bgColor = '#e5e7eb';
                              $icon = '📦';
                              break;
                      }
                      
                      // Convert UTC to Philippine Time
                      $utcTime = new DateTime($activity['created_at'], new DateTimeZone('UTC'));
                      $utcTime->setTimezone(new DateTimeZone('Asia/Manila'));
                      $timeAgo = $utcTime->format('M d, Y g:i A');
                      
                      echo '<div style="display:flex; gap:12px; padding:10px; background:' . $bgColor . '; border-radius:6px; align-items:start;">';
                      echo '<span style="color:' . $iconColor . '; font-weight:bold; font-size:16px; line-height:1.4;">' . $icon . '</span>';
                      echo '<div style="flex:1;">';
                      echo '<div style="font-size:13px; color:#111827; font-weight:500; margin-bottom:2px;">' . htmlspecialchars($activity['description']) . '</div>';
                      echo '<div style="font-size:11px; color:#6b7280;">' . htmlspecialchars($timeAgo) . ' (PHT)</div>';
                      echo '</div>';
                      echo '</div>';
                  }
                  echo '</div>';
              } else {
                  echo '<div style="padding:16px; text-align:center; color:#9ca3af; font-size:13px; background:#f9fafb; border-radius:6px;">No recent activity</div>';
              }
          } catch (Exception $e) {
              echo '<div style="padding:12px; color:#ef4444; font-size:13px;">Error loading activity log</div>';
          }
          ?>
        </div>
      </section>

      <aside class="card" style="background-color: white;">
        <h3 style="margin-top:0;">Semester Management</h3>
        <p class="subtitle">Manage application periods and semester settings</p>

        <div class="action-item" style="margin-top:14px; padding:16px; border:1px solid #e5e7eb; border-radius:8px;">
          <h4 style="margin:0 0 12px 0;">Semester Schedule</h4>
          <div style="margin-bottom:12px;">
            <span style="font-size:12px; color:#666;">Current: </span>
            <span style="padding:2px 8px; border-radius:12px; font-size:11px; font-weight:bold; background:#dcfce7; color:#166534;">
              <?php echo strtoupper($currentSemester); ?>
            </span>
          </div>
          <form method="post" action="" id="semesterForm" style="display:flex; flex-direction:column; gap:12px;">
            <input type="hidden" name="action" value="set_semester">
            <div style="display:flex; gap:12px; align-items:center;">
              <div style="flex:1;">
                <label style="font-size:12px; color:#666;">Academic Year:</label>
                <input type="text" name="academic_year" placeholder="2024-2025" required style="width:100%; padding:6px; border:1px solid #ddd; border-radius:4px;">
              </div>
              <div style="flex:1">
                <label style="font-size:12px; color:#666;">Semester:</label>
                <select name="semester_number" required style="padding:6px; border:1px solid #ddd; border-radius:4px;">
                  <option value="1">1st Semester</option>
                  <option value="2">2nd Semester</option>
                </select>
              </div>
            </div>
            <div style="display:flex; gap:12px; align-items:center;">
              <div style="flex:1;">
                <label style="font-size:12px; color:#666;">Start Date:</label>
                <input type="date" name="start_date" required style="width:100%; padding:6px; border:1px solid #ddd; border-radius:4px;">
              </div>
              <div style="flex:1;">
                <label style="font-size:12px; color:#666;">End Date:</label>
                <input type="date" name="end_date" required style="width:100%; padding:6px; border:1px solid #ddd; border-radius:4px;">
              </div>
            </div>
            <button type="submit" style="padding:8px 16px; background:#059669; color:white; border:none; border-radius:4px; cursor:pointer;">Set Semester Schedule</button>
          </form>
          
          <div style="margin-top:16px; padding-top:16px; border-top:1px solid #e5e7eb;">
            <h5 style="margin:0 0 8px 0; font-size:14px;">Application Control</h5>
            <div style="margin-bottom:8px;">
              <span style="font-size:12px; color:#666;">Status: </span>
              <span style="padding:2px 8px; border-radius:12px; font-size:11px; font-weight:bold; <?php echo $appStatus == 'open' ? 'background:#dcfce7; color:#166534;' : ($appStatus == 'closed' ? 'background:#fecaca; color:#991b1b;' : 'background:#f3f4f6; color:#374151;'); ?>">
                <?php echo strtoupper($appStatus); ?>
              </span>
            </div>
            <div style="display:flex; gap:8px;">
              <form method="post" action="" style="display:inline;">
                <input type="hidden" name="action" value="toggle_applications">
                <input type="hidden" name="app_status" value="open">
                <button type="submit" style="padding:6px 12px; background:#10b981; color:white; border:none; border-radius:4px; cursor:pointer; font-size:12px;">Open Applications</button>
              </form>
              <form method="post" action="" style="display:inline;">
                <input type="hidden" name="action" value="toggle_applications">
                <input type="hidden" name="app_status" value="closed">
                <button type="submit" style="padding:6px 12px; background:#ef4444; color:white; border:none; border-radius:4px; cursor:pointer; font-size:12px;">Close Applications</button>
              </form>
            </div>
          </div>
          
          <div style="margin-top:12px; padding-top:12px; border-top:1px solid #e5e7eb;">
            <h5 style="margin:0 0 8px 0; font-size:14px;">Semester Management</h5>
            <form method="post" action="" style="display:inline;">
              <input type="hidden" name="action" value="end_semester">
              <button type="submit" onclick="return confirm('Are you sure you want to end the current semester? This will archive all rankings.')" 
                      style="padding:6px 12px; background:#ef4444; color:white; border:none; border-radius:4px; cursor:pointer; font-size:12px;">End Current Semester</button>
            </form>
            <p style="font-size:11px; color:#6b7280; margin:4px 0 0 0;">Archives current rankings and prepares for next semester</p>
          </div>
        </div>
      </aside>
    </div>
  </main>

  <script>
    const chartLabels = <?php echo json_encode($chartLabels, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
    const chartData = <?php echo json_encode($chartData, JSON_NUMERIC_CHECK); ?>;

    const ctx = document.getElementById('trendChart').getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: chartLabels,
        datasets: [{
          label: 'Applications',
          data: chartData,
          backgroundColor: '#590c0d74',
          borderColor: '#7e1516',
          fill: true,
          tension: 0.3,
          pointRadius: 4
        }]
      },
      options: {
        plugins: { legend: { display: true } },
        scales: {
          x: { grid: { display:false } },
          y: { beginAtZero:true, ticks: { precision:0 } }
        },
        responsive: true,
        maintainAspectRatio: false
      }
    });

    // Set minimum date for start_date to today
    document.querySelector('input[name="start_date"]').min = new Date().toISOString().split('T')[0];
    
    // Ensure end_date is after start_date
    document.querySelector('input[name="start_date"]').addEventListener('change', function() {
      document.querySelector('input[name="end_date"]').min = this.value;
    });
    
    // Handle active semester warning
    <?php if ($message === 'WARN_ACTIVE_SEMESTER'): ?>
    alert('There is already an active semester. Please end the current semester first using the "End Current Semester" button before creating a new one.');
    <?php endif; ?>
  </script>
</body>
</html>
