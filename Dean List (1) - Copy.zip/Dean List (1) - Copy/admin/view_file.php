<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Admin check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    exit('Access denied');
}

$student_id = $_GET['student_id'] ?? '';
if (empty($student_id)) {
    http_response_code(400);
    exit('No student ID specified');
}

// Get file path from database
$db = (new Database())->getConnection();
$stmt = $db->prepare("SELECT file_path FROM applications WHERE student_id = ? ORDER BY created_at DESC LIMIT 1");
$stmt->execute([$student_id]);
$file_path = $stmt->fetchColumn();

if (!$file_path) {
    // Fallback: show message for applications without file paths
    ?><!DOCTYPE html>
<html><head><title>No File Found</title><style>
body{font-family:Arial,sans-serif;margin:0;padding:40px;background:#f5f5f5;text-align:center}
.container{max-width:500px;margin:0 auto;background:white;padding:30px;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.1)}
.icon{font-size:48px;margin-bottom:20px}
h2{color:#ef4444;margin-bottom:20px}
.btn{padding:10px 20px;background:#2e55a6;color:white;border:none;border-radius:5px;cursor:pointer;text-decoration:none;display:inline-block}
</style></head><body>
<div class="container">
<div class="icon">📄</div>
<h2>No File Found</h2>
<p><strong>Student ID:</strong> <?php echo htmlspecialchars($student_id); ?></p>
<p>This student's application does not have an uploaded file, or the file was submitted before the file upload system was implemented.</p>
<p>Please ask the student to resubmit their application with the required certified grades document.</p>
<a href="javascript:window.close()" class="btn">Close Window</a>
</div></body></html><?php
    exit;
}

$full_path = __DIR__ . '/../shared/' . $file_path;
if (!file_exists($full_path)) {
    // Try alternative paths
    $alt_paths = [
        __DIR__ . '/../' . $file_path,
        __DIR__ . '/' . $file_path,
        __DIR__ . '/../uploads/applications/' . basename($file_path),
        '/home/u832832306/domains/ccsdlapplication.online/public_html/' . $file_path
    ];
    
    foreach ($alt_paths as $alt_path) {
        if (file_exists($alt_path)) {
            $full_path = $alt_path;
            break;
        }
    }
}

if (!file_exists($full_path)) {
    http_response_code(404);
    exit('File not found on server: ' . $file_path);
}

// Get file info
$file_info = pathinfo($full_path);
$file_extension = strtolower($file_info['extension']);
$file_name = $file_info['basename'];

// Set appropriate content type
if ($file_extension === 'pdf') {
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="' . $file_name . '"');
} elseif (in_array($file_extension, ['jpg', 'jpeg', 'png'])) {
    $mime_types = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png'
    ];
    header('Content-Type: ' . $mime_types[$file_extension]);
    header('Content-Disposition: inline; filename="' . $file_name . '"');
} else {
    http_response_code(400);
    exit('Unsupported file type');
}

// Output the file
readfile($full_path);
exit;
?>