<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Admin check
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: admin_users.php');
    exit();
}

$student_id = trim($_POST['student_id'] ?? '');

if (empty($student_id)) {
    header('Location: admin_users.php?error=invalid_id');
    exit();
}

try {
    $db = (new Database())->getConnection();
    $db->beginTransaction();

    // Delete from all tables
    $db->prepare("DELETE FROM rankings_archive WHERE student_id = ?")->execute([$student_id]);
    $db->prepare("DELETE FROM student_rankings WHERE student_id = ?")->execute([$student_id]);
    $db->prepare("DELETE FROM applications WHERE student_id = ?")->execute([$student_id]);
    $db->prepare("DELETE FROM students WHERE student_id = ?")->execute([$student_id]);
    $db->prepare("DELETE FROM users WHERE student_id = ?")->execute([$student_id]);

    $db->commit();
    header('Location: admin_users.php?deleted=1');
    exit();

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    error_log("Delete error: " . $e->getMessage());
    header('Location: admin_users.php?error=delete_failed');
    exit();
}
?>