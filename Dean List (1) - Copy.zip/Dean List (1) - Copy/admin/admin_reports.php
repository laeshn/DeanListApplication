<?php
// admin_reports.php - Enhanced Reports page with Dean's Listers, filters, and ranking history
session_start();
require_once __DIR__ . '/../config/database.php';

// Admin check
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: admin_login.php");
    exit();
}

function asset($file) {
    $base = dirname($_SERVER['SCRIPT_NAME']);
    if ($base === '/' || $base === '\\' || $base === '.') $base = '';
    return ($base === '' ? '' : rtrim($base, '/')) . '/' . ltrim($file, '/');
}

$db = (new Database())->getConnection();

// Determine current page for nav active state
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');

// Get filter parameters
$selectedSemester = $_GET['semester'] ?? 'current';
$selectedCourse = $_GET['course'] ?? 'all';
$selectedYear = $_GET['year'] ?? 'all';
$selectedAcademicYear = $_GET['academic_year'] ?? 'all';

// Get current semester info
$currentSemester = 'No Active Semester';
$currentAcadYear = 'Not Set';
try {
    $semQuery = "SELECT cs.semester_number, ay.academic_year 
                 FROM current_semester cs 
                 LEFT JOIN semester s ON 1=1 
                 LEFT JOIN acad_year ay ON ay.acadID = s.acadID 
                 ORDER BY cs.id DESC LIMIT 1";
    $semStmt = $db->prepare($semQuery);
    $semStmt->execute();
    $semData = $semStmt->fetch(PDO::FETCH_ASSOC);
    if ($semData) {
        $semNum = $semData['semester_number'];
        $currentSemester = ($semNum == '1' ? '1st' : '2nd') . ' Semester';
        $currentAcadYear = $semData['academic_year'] ?? 'Not Set';
    }
} catch (Exception $e) {
    // Keep defaults
}

// Totals (same as before)
$totals = [
    'users' => 0,
    'students' => 0,
    'admins' => 0,
    'applications' => 0,
    'under_review' => 0,
    'approved' => 0
];

try {
    $stmt = $db->query("SELECT COUNT(*) FROM users");
    $totals['users'] = (int)$stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE role = 'student'");
    $stmt->execute(); $totals['students'] = (int)$stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin'");
    $stmt->execute(); $totals['admins'] = (int)$stmt->fetchColumn();

    // applications totals (applications table expected)
    $stmt = $db->query("SELECT COUNT(*) FROM applications");
    $totals['applications'] = (int)$stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COUNT(*) FROM applications WHERE status = 'under-review'");
    $stmt->execute(); $totals['under_review'] = (int)$stmt->fetchColumn();

    // treat 'approved' or 'accepted' as approved; adjust if your app uses different values
    $stmt = $db->prepare("SELECT COUNT(*) FROM applications WHERE status IN ('approved','accepted')");
    $stmt->execute(); $totals['approved'] = (int)$stmt->fetchColumn();
} catch (PDOException $e) {
    error_log("Reports: DB error fetching totals: " . $e->getMessage());
}

// Dean's Listers - accepted applications with filters
$deansListers = [];
try {
    $sql = "
        SELECT
            a.id AS application_id,
            a.student_id AS student_number,
            a.gpa AS gpa,
            a.created_at,
            (CASE WHEN a.semID % 2 = 1 THEN 1 ELSE 2 END) AS semester_number,
            ay.academic_year,
            COALESCE(s.full_name, u.email, '—') AS student_name,
            COALESCE(s.course,'—') AS course,
            COALESCE(s.year_level, '') AS year_level
        FROM applications a
        LEFT JOIN students s ON s.student_id = a.student_id
        LEFT JOIN users u ON u.user_id = a.user_id
        LEFT JOIN acad_year ay ON ay.acadID = a.acadID
        WHERE a.status IN ('approved','accepted')
    ";

    $params = [];
    $conditions = [];

    // Semester filter
    if ($selectedSemester !== 'all') {
        $conditions[] = "(CASE WHEN a.semID % 2 = 1 THEN 1 ELSE 2 END) = :semester_num";
        $params[':semester_num'] = $selectedSemester;
    }

    // Course filter
    if ($selectedCourse !== 'all') {
        $conditions[] = "s.course = :course";
        $params[':course'] = $selectedCourse;
    }

    // Academic year filter
    if ($selectedAcademicYear !== 'all') {
        $conditions[] = "ay.academic_year = :academic_year";
        $params[':academic_year'] = $selectedAcademicYear;
    }

    if (!empty($conditions)) {
        $sql .= " AND " . implode(" AND ", $conditions);
    }

    $sql .= " ORDER BY a.gpa DESC, a.created_at DESC";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $deansListers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Reports: DB error fetching dean's listers: " . $e->getMessage());
}

// Ranking History - Include both current and archived rankings (NO FILTERS)
$rankingHistory = [];
try {
    $sql = "
        SELECT
            sr.student_id,
            sr.full_name,
            sr.course,
            sr.year_level,
            (CASE WHEN sr.semID % 2 = 1 THEN 1 ELSE 2 END) AS semester_number,
            ay.academic_year,
            sr.gpa,
            sr.credits,
            sr.created_at,
            'current' as source
        FROM student_rankings sr
        LEFT JOIN acad_year ay ON ay.acadID = sr.acadID
        UNION ALL
        SELECT
            ra.student_id,
            s.full_name,
            s.course,
            s.year_level,
            (CASE WHEN ra.semID % 2 = 1 THEN 1 ELSE 2 END) AS semester_number,
            ay.academic_year,
            ra.gpa,
            CASE 
                WHEN ra.grades_json IS NOT NULL AND ra.grades_json != '' 
                THEN CHAR_LENGTH(ra.grades_json) - CHAR_LENGTH(REPLACE(ra.grades_json, ',', '')) + 1
                ELSE 0 
            END as credits,
            ra.archived_at as created_at,
            'archive' as source
        FROM rankings_archive ra
        JOIN students s ON s.student_id = ra.student_id
        LEFT JOIN acad_year ay ON ay.acadID = ra.acadID
        ORDER BY created_at DESC
        LIMIT 50
    ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $rankingHistory = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Reports: DB error fetching ranking history: " . $e->getMessage());
}

// Filtered Rankings - NEW TABLE with filters applied
$filteredRankings = [];
try {
    $sql = "
        SELECT * FROM (
            SELECT
                sr.student_id,
                sr.full_name,
                sr.course,
                sr.year_level,
                (CASE WHEN sr.semID % 2 = 1 THEN 1 ELSE 2 END) AS semester_number,
                ay.academic_year,
                sr.gpa,
                sr.credits,
                sr.created_at,
                'current' as source
            FROM student_rankings sr
            LEFT JOIN acad_year ay ON ay.acadID = sr.acadID
            UNION ALL
            SELECT
                ra.student_id,
                s.full_name,
                s.course,
                s.year_level,
                (CASE WHEN ra.semID % 2 = 1 THEN 1 ELSE 2 END) AS semester_number,
                ay.academic_year,
                ra.gpa,
                CASE 
                    WHEN ra.grades_json IS NOT NULL AND ra.grades_json != '' 
                    THEN CHAR_LENGTH(ra.grades_json) - CHAR_LENGTH(REPLACE(ra.grades_json, ',', '')) + 1
                    ELSE 0 
                END as credits,
                ra.archived_at as created_at,
                'archive' as source
            FROM rankings_archive ra
            JOIN students s ON s.student_id = ra.student_id
            LEFT JOIN acad_year ay ON ay.acadID = ra.acadID
        ) AS combined
        WHERE 1=1
    ";
    
    $filteredParams = [];
    $filteredConditions = [];
    
    // Apply filters
    if ($selectedSemester !== 'all') {
        $filteredConditions[] = "semester_number = :filt_semester_num";
        $filteredParams[':filt_semester_num'] = $selectedSemester;
    }
    
    if ($selectedCourse !== 'all') {
        $filteredConditions[] = "course = :filt_course";
        $filteredParams[':filt_course'] = $selectedCourse;
    }
    
    if ($selectedAcademicYear !== 'all') {
        $filteredConditions[] = "academic_year = :filt_academic_year";
        $filteredParams[':filt_academic_year'] = $selectedAcademicYear;
    }
    
    if (!empty($filteredConditions)) {
        $sql .= " AND " . implode(" AND ", $filteredConditions);
    }
    
    $sql .= " ORDER BY created_at DESC LIMIT 200";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($filteredParams);
    $filteredRankings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Reports: DB error fetching filtered rankings: " . $e->getMessage());
}

// Get available courses for filter
$availableCourses = [];
try {
    $stmt = $db->query("SELECT DISTINCT course FROM students WHERE course IS NOT NULL ORDER BY course");
    $availableCourses = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    error_log("Reports: DB error fetching courses: " . $e->getMessage());
}

// Get available years for filter
$availableYears = [];
try {
    $stmt = $db->query("SELECT DISTINCT year_level FROM students WHERE year_level IS NOT NULL ORDER BY year_level");
    $availableYears = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    error_log("Reports: DB error fetching years: " . $e->getMessage());
}

// Get available academic years from acad_year table
$availableAcademicYears = [];
try {
    $stmt = $db->query("
        SELECT DISTINCT academic_year 
        FROM acad_year 
        WHERE academic_year IS NOT NULL 
        ORDER BY academic_year DESC
    ");
    $availableAcademicYears = $stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    error_log("Reports: DB error fetching academic years: " . $e->getMessage());
}

// Archives per semester/academic year
$archivesBySemester = [];
try {
    $stmt = $db->prepare("
        SELECT 
            (CASE WHEN ra.semID % 2 = 1 THEN 1 ELSE 2 END) AS semester_number,
            ay.academic_year,
            COUNT(*) as archived_count,
            MAX(ra.archived_at) as last_archived
        FROM rankings_archive ra
        LEFT JOIN acad_year ay ON ay.acadID = ra.acadID
        GROUP BY ra.semID, ra.acadID, ay.academic_year
        ORDER BY ay.academic_year DESC, semester_number DESC
    ");
    $stmt->execute();
    $archivesBySemester = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Reports: DB error fetching archives: " . $e->getMessage());
}

// Per-course aggregates
$byCourse = [];
try {
    $sql = "
        SELECT 
            COALESCE(s.course, 'Unknown') AS course,
            COUNT(DISTINCT s.student_id) AS student_count,
            COUNT(CASE WHEN a.status IN ('approved','accepted') THEN 1 END) AS application_count
        FROM students s
        LEFT JOIN applications a ON a.student_id = s.student_id
        WHERE s.course IS NOT NULL AND s.course != ''
        GROUP BY s.course
        ORDER BY s.course ASC
    ";
    
    $stmt = $db->query($sql);
    $byCourse = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Reports: DB error byCourse: " . $e->getMessage());
}

// helper to format datetime safely
function fmt_datetime($s) {
    if (empty($s)) return '—';
    $t = strtotime($s);
    if ($t === false) return htmlspecialchars($s);
    return date('M d, Y H:i', $t);
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Reports - Admin</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link rel="stylesheet" href="<?php echo asset('admin.css'); ?>">
  <style>
    @media print {
      body * { visibility: hidden; }
      #printArea, #printArea * { visibility: visible; }
      #printArea { position: absolute; left: 0; top: 0; width: 100%; padding: 0; }
      .admin-header, .page-header, .card:first-of-type { display: none !important; }
      .ranking-history-section { display: none !important; }
      table { page-break-inside: auto; }
      tr { page-break-inside: avoid; page-break-after: auto; }
      thead { display: table-header-group; }
    }
  </style>
</head>
<body>

  <!-- Inline header/navigation so Reports page shows same nav -->
  <nav class="admin-header" role="navigation" aria-label="Admin navigation">
    <div class="header-content">
        <div class="nav-brand">
            <h1 class="portal-title">Admin Portal</h1>
        </div>

        <div class="main-nav" role="menubar" aria-label="Main">
            <a role="menuitem"
               href="<?php echo asset('admin_homepage.php'); ?>"
               class="<?php echo $currentPage === 'admin_homepage.php' ? 'active' : ''; ?>">Home</a>

            <a role="menuitem"
               href="<?php echo asset('admin_applications.php'); ?>"
               class="<?php echo $currentPage === 'admin_applications.php' ? 'active' : ''; ?>">Status</a>

            <a role="menuitem"
               href="<?php echo asset('../shared/rankings.php'); ?>"
               class="<?php echo $currentPage === 'rankings.php' ? 'active' : ''; ?>">Rankings</a>

            <a role="menuitem"
               href="<?php echo asset('admin_users.php'); ?>"
               class="<?php echo $currentPage === 'admin_users.php' ? 'active' : ''; ?>">Manage Users</a>

            <a role="menuitem"
               href="<?php echo asset('admin_reports.php'); ?>"
               class="<?php echo $currentPage === 'admin_reports.php' ? 'active' : ''; ?>">Reports</a>
        </div>

        <div class="user-nav" aria-label="User">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['admin'] ?? 'Admin'); ?></span>
            <a href="<?php echo asset('admin_logout.php'); ?>">Logout</a>
        </div>
    </div>
  </nav>

  <main class="container page-container">
    <div class="page-header" style="display: flex; justify-content: space-between; align-items: center;">
      <div>
        <h2>Reports & Analytics</h2>
        <div style="margin: 8px 0; padding: 8px 12px; background: #f8fafc; border-radius: 6px; font-size: 14px; color: #64748b;">
          <strong>Current Period:</strong> <?php echo htmlspecialchars($currentSemester); ?> • Academic Year <?php echo htmlspecialchars($currentAcadYear); ?>
        </div>
        <p>Dean's Listers, rankings history, and comprehensive analytics.</p>
      </div>
      <button id="printReport" class="print">Print Summary</button>
    </div>

    <!-- Filters Section -->
    <div class="card" style="margin-bottom: 1em; background-color: white;">
      <h3 style="color: #2e55a6;">Filters</h3>
      <form method="GET" class="filters">
          <select name="semester">
            <option value="all">All Semesters</option>
            <option value="1" <?php echo $selectedSemester === '1' ? 'selected' : ''; ?>>1st Semester</option>
            <option value="2" <?php echo $selectedSemester === '2' ? 'selected' : ''; ?>>2nd Semester</option>
          </select>

          <select name="course">
            <option value="all">All Courses</option>
            <?php foreach ($availableCourses as $course): ?>
              <option value="<?php echo htmlspecialchars($course); ?>" <?php echo $selectedCourse === $course ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($course); ?>
              </option>
            <?php endforeach; ?>
          </select>

          <select name="academic_year">
            <option value="all">All Academic Years</option>
            <?php foreach ($availableAcademicYears as $academicYear): ?>
              <option value="<?php echo htmlspecialchars($academicYear); ?>" <?php echo $selectedAcademicYear === $academicYear ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($academicYear); ?>
              </option>
            <?php endforeach; ?>
          </select>

          <button type="submit" class="apply-filters">Apply Filters</button>
        </form>
    </div>

    <!-- Printable area -->
    <div class="card" style="background-color: white;">
      <div id="printArea">

        <!-- Summary Statistics -->
        <section class="stats-grid">
          <div class="card stat-card">
            <h4>Students</h4>
            <div class="stat-value"><?php echo number_format($totals['students']); ?></div>
            <p class="stat-note">Total enrolled</p>
          </div>
          <div class="card stat-card">
            <h4>Applications</h4>
            <div class="stat-value"><?php echo number_format($totals['applications']); ?></div>
            <p class="stat-note">Under review: <?php echo number_format($totals['under_review']); ?> • Approved: <?php echo number_format($totals['approved']); ?></p>
          </div>
          <div class="card stat-card">
            <h4>Dean's Listers</h4>
            <div class="stat-value"><?php echo number_format(count($deansListers)); ?></div>
            <p class="stat-note">Accepted applications</p>
          </div>
        </section>

        <!-- Dean's Listers Section -->
        <section class="table-card">
          <h3 class="bold-text">Dean's Listers</h3>
          <p class="subtext">Students who achieved Dean's List status (accepted applications)</p>

          <?php if (count($deansListers) === 0): ?>
            <p class="subtext">No Dean's Listers found for the selected filters.</p>
          <?php else: ?>
            <div class="applications-table">
              <table aria-label="Dean's Listers table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Student Name</th>
                    <th>Student ID</th>
                    <th>GPA</th>
                    <th>Year Level</th>
                    <th>Course</th>
                    <th>Semester</th>
                    <th>Academic Year</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($deansListers as $i => $student): ?>
                    <tr>
                      <td><?php echo $i + 1; ?></td>
                      <td><?php echo htmlspecialchars($student['student_name']); ?></td>
                      <td><?php echo htmlspecialchars($student['student_number'] ?? '—'); ?></td>
                      <td><?php echo htmlspecialchars($student['gpa'] ?: '—'); ?></td>
                      <td><?php echo htmlspecialchars($student['year_level'] ?: '—'); ?></td>
                      <td><?php echo htmlspecialchars($student['course'] ?: '—'); ?></td>
                      <td><?php 
                        $semNum = $student['semester_number'] ?? '';
                        $semDisplay = $semNum == '1' ? '1st Semester' : ($semNum == '2' ? '2nd Semester' : '—');
                        echo htmlspecialchars($semDisplay);
                      ?></td>
                      <td><?php echo htmlspecialchars($student['academic_year'] ?: '—'); ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
            <p class="muted">Total Dean's Listers: <strong><?php echo count($deansListers); ?></strong></p>
          <?php endif; ?>
        </section>

        <!-- Archives by Semester Section -->
        <section class="table-card">
          <h3 class="bold-text">Archives by Semester</h3>
          <p class="subtext">Historical data archived per semester and academic year</p>
          
          <?php if (count($archivesBySemester) === 0): ?>
            <p class="muted">No archived data available.</p>
          <?php else: ?>
            <div class="applications-table">
              <table aria-label="Archives by Semester table">
                <thead>
                  <tr>
                    <th>Academic Year</th>
                    <th>Semester</th>
                    <th>Archived Records</th>
                    <th>Last Archived</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($archivesBySemester as $archive): ?>
                    <tr>
                      <td><?php echo htmlspecialchars($archive['academic_year'] ?: '—'); ?></td>
                      <td><?php 
                        $semNum = $archive['semester_number'] ?? '';
                        $semDisplay = $semNum == '1' ? '1st Semester' : ($semNum == '2' ? '2nd Semester' : '—');
                        echo htmlspecialchars($semDisplay);
                      ?></td>
                      <td><?php echo number_format($archive['archived_count']); ?></td>
                      <td><?php echo htmlspecialchars(fmt_datetime($archive['last_archived'])); ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
            <p class="muted">Total Archive Records: <strong><?php echo number_format(array_sum(array_column($archivesBySemester, 'archived_count'))); ?></strong></p>
          <?php endif; ?>
        </section>

        <!-- Applications by Course -->
        <section class="table-card">
          <h3 class="bold-text">Applications by Course</h3>
          <p class="subtext">Student and application counts per course</p>
          <div class="applications-table">
          <table>
            <thead>
              <tr style="text-align:left; border-bottom:1px solid #e6e7eb;">
                <th>Course</th>
                <th style="text-align:right;">Students</th>
                <th style="text-align:right;">Applications</th>
              </tr>
            </thead>
            <tbody>
              <?php if (count($byCourse) === 0): ?>
                <tr><td colspan="3" class="muted">No course data available.</td></tr>
              <?php else: ?>
                <?php foreach ($byCourse as $r): ?>
                  <tr>
                    <td><?php echo htmlspecialchars($r['course'] ?: '—'); ?></td>
                    <td style="text-align:right;"><?php echo number_format($r['student_count']); ?></td>
                    <td style="text-align:right;"><?php echo number_format($r['application_count']); ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
          </div>
        </section>

        <!-- Ranking History Section -->
        <section class="ranking-history-section table-card">
          <h3 class="bold-text">Ranking History</h3>
          <p class="subtext">Historical ranking data and performance changes over time</p>

          <?php if (count($rankingHistory) === 0): ?>
            <p class="muted">No ranking history available.</p>
          <?php else: ?>
            <div class="applications-table">
              <table aria-label="Ranking History table">
                <thead>
                  <tr>
                    <th>Student Name</th>
                    <th>Student ID</th>
                    <th>Course</th>
                    <th>Year Level</th>
                    <th>Semester</th>
                    <th>Academic Year</th>
                    <th>GPA</th>
                    <th>Credits</th>
                    <th>Recorded</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($rankingHistory as $record): ?>
                    <tr>
                      <td><?php echo htmlspecialchars($record['full_name']); ?></td>
                      <td><?php echo htmlspecialchars($record['student_id']); ?></td>
                      <td><?php echo htmlspecialchars($record['course']); ?></td>
                      <td><?php echo htmlspecialchars($record['year_level']); ?></td>
                      <td><?php 
                        $semNum = $record['semester_number'] ?? '';
                        $semDisplay = $semNum == '1' ? '1st Semester' : ($semNum == '2' ? '2nd Semester' : '—');
                        echo htmlspecialchars($semDisplay);
                      ?></td>
                      <td><?php echo htmlspecialchars($record['academic_year']); ?></td>
                      <td><?php echo htmlspecialchars($record['gpa']); ?></td>
                      <td><?php echo htmlspecialchars($record['credits']); ?></td>
                      <td><?php echo htmlspecialchars(fmt_datetime($record['created_at'])); ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </section>

        <p class="muted" style="margin-top:24px; padding-top:20px; border-top:1px solid #e5e7eb;">
          Report generated on: <?php echo date('Y-m-d H:i:s'); ?> (UTC)
        </p>
      </div>
    </div>
  </main>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      const btn = document.getElementById('printReport');
      if (!btn) return;
      btn.addEventListener('click', function () {
        window.print();
      });
    });
  </script>
</body>
</html>
