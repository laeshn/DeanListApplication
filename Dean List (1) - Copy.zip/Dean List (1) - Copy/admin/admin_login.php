<?php
session_start();
require_once '../config/database.php';

// Debug information
$debug = true;
$debug_info = [];

function asset($file) {
    $base = dirname($_SERVER['SCRIPT_NAME']);
    if ($base === '/' || $base === '\\' || $base === '.') {
        $base = '';
    }
    return ($base === '' ? '' : rtrim($base, '/')) . '/' . ltrim($file, '/');
}

$error_message = ''; // Initialize error_message
$current_time = date('Y-m-d H:i:s');
$current_user = 'czam-exe';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $database = new Database();
    $db = $database->getConnection();
    
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (!empty($email) && !empty($password)) {
        try {
            // Check specifically for admin users
            $query = "SELECT * FROM users WHERE email = :email AND role = 'admin'";
            $stmt = $db->prepare($query);
            $stmt->bindParam(":email", $email);
            $stmt->execute();
            
            if ($stmt->rowCount() > 0) {
              $user = $stmt->fetch(PDO::FETCH_ASSOC);
              if ($password == $user['password']) { // In production, use password_verify()
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['role'] = 'admin';
                $_SESSION['email'] = $user['email']; // Add email to session
        
        // Debug info
        error_log('Login successful. Session data: ' . print_r($_SESSION, true));
        
        // Make sure there's no output before this header
        header("Location: admin_homepage.php");
        exit();
    } else {
        $error_message = "Invalid password";
    }
} else {
                $error_message = "Invalid admin credentials";
            }
        } catch (PDOException $e) {
            $error_message = "Database error occurred";
        }
    } else {
        $error_message = "Please enter both email and password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Login - Dean's List</title>
  <link rel="stylesheet" href="<?php echo asset('../login.css'); ?>" />
</head>
<body>
  <div class="background-blur"></div>

  <header>
    <div class="logos" style="display: inline;">
      <img src="<?php echo asset('../resource/logo.png'); ?>" alt="LSPU Logo" class="logo" />
      <img src="<?php echo asset('../resource/ccs_logo.png'); ?>" alt="CCS Logo" class="logo" />
    </div>
    <h1>DEAN'S LIST APPLICATION</h1>
  </header>

  <main style="display:flex; justify-content:center; padding-top:40px;">
    <section class="portal admin-login" style="max-width:420px; width:100%;">
      <div class="icon">
        <!-- admin shield icon -->
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <path d="M12 2l7 3v5c0 5-3.58 9.74-7 11-3.42-1.26-7-6-7-11V5l7-3z" stroke="#6b46c1" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </div>
      <h2>Admin Portal</h2>
      <p>Secure access to the administration dashboard</p>

      <?php if (!empty($error_message)): ?>
        <div style="color:#fff;background:#ef4444;padding:10px;border-radius:8px;margin:10px 0;">
          <?php echo htmlspecialchars($error_message, ENT_QUOTES, 'UTF-8'); ?>
        </div>
      <?php endif; ?>

      <form method="post" action="" style="display:block;">
        <label for="email">Admin Email</label>
        <input id="email" name="email" type="email" placeholder="admin@university.edu" style="display:block; width:100%; padding:12px; margin:10px 0 18px; border-radius:8px; border:1px solid #eee; background:#f7f7f8;" required />

        <label for="password">Password</label>
        <input id="password" name="password" type="password" placeholder="" style="display:block; width:100%; padding:12px; margin:10px 0 18px; border-radius:8px; border:1px solid #eee; background:#f7f7f8;" required />

        <button type="submit" class="btn student-btn" style="text-align:center;">Secure Login</button>
      </form>
    </section>
  </main>

</body>
</html>
