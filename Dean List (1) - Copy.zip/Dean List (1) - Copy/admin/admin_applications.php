<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Admin check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin_login.php");
    exit();
}

$db = (new Database())->getConnection();
$message = '';

// Get application ID
$app_id = $_GET['id'] ?? null;
if (!$app_id) {
    header("Location: admin_applications.php");
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'accept') {
        try {
            $stmt = $db->prepare("UPDATE applications SET status = 'accepted' WHERE id = ?");
            $stmt->execute([$app_id]);
            $message = "Application accepted successfully!";
        } catch (Exception $e) {
            $message = "Error accepting application: " . $e->getMessage();
        }
    } elseif ($action == 'reject') {
        $rejection_reason = $_POST['rejection_reason'] ?? '';
        $custom_reason = $_POST['custom_reason'] ?? '';
        
        $reason = ($rejection_reason === 'others') ? $custom_reason : $rejection_reason;
        
        try {
            // Add rejection_reason column if it doesn't exist
            $db->exec("ALTER TABLE applications ADD COLUMN rejection_reason TEXT NULL");
        } catch (Exception $e) {
            // Column might already exist
        }
        
        try {
            $stmt = $db->prepare("UPDATE applications SET status = 'rejected', rejection_reason = ? WHERE id = ?");
            $stmt->execute([$reason, $app_id]);
            $message = "Application rejected successfully!";
        } catch (Exception $e) {
            $message = "Error rejecting application: " . $e->getMessage();
        }
    }
}

// Fetch application details
$application = null;
try {
    $sql = "SELECT a.*, s.full_name, s.course, s.year_level, u.email
            FROM applications a
            LEFT JOIN students s ON s.student_id = a.student_id
            LEFT JOIN users u ON u.user_id = a.user_id
            WHERE a.id = ?";
    $stmt = $db->prepare($sql);
    $stmt->execute([$app_id]);
    $application = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$application) {
        header("Location: admin_applications.php");
        exit();
    }
} catch (Exception $e) {
    $message = "Error loading application: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Application - Admin</title>
    <link rel="stylesheet" href="admin.css">
</head>
<body>
    <nav class="admin-header">
        <div class="header-content">
            <div class="nav-brand">
                <h1 class="portal-title">Admin Portal</h1>
            </div>
            <div class="main-nav">
                <a href="admin_homepage.php">Home</a>
                <a href="admin_applications.php" class="active">Status</a>
                <a href="../shared/rankings.php">Rankings</a>
                <a href="admin_users.php">Manage Users</a>
                <a href="admin_reports.php">Reports</a>
            </div>
            <div class="user-nav">
                <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? 'Admin'); ?></span>
                <a href="admin_logout.php">Logout</a>
            </div>
        </div>
    </nav>

    <main class="applications-container">
        <div><a href="admin_applications.php" class="back">Back to Status</a></div>

        <section class="applications-list">
            <h3 style="margin-bottom:30px;"class="bold-text">Application Details</h3>
            
            <?php if ($message): ?>
                <div style="color:#fff;background:<?php echo strpos($message, 'Error') !== false ? '#ef4444' : '#10b981'; ?>;padding:10px;border-radius:8px;margin-bottom:12px;">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <?php if ($application): ?>
                <div class="card" style="background:white; margin-bottom: 20px;">
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin:20px 0;">
                        <div>
                            <h4 class="bold-text">Student Information</h4>
                            <p><strong>Name:</strong> <?php echo htmlspecialchars($application['full_name'] ?? 'N/A'); ?></p>
                            <p><strong>Student ID:</strong> <?php echo htmlspecialchars($application['student_id'] ?? 'N/A'); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($application['email'] ?? 'N/A'); ?></p>
                            <p><strong>Course:</strong> <?php echo htmlspecialchars($application['course'] ?? 'N/A'); ?></p>
                            <p><strong>Year Level:</strong> <?php echo htmlspecialchars($application['year_level'] ?? 'N/A'); ?></p>
                        </div>
                        
                        <div>
                            <h4 class="bold-text">Application Information</h4>
                            <p><strong>GPA:</strong> <?php echo htmlspecialchars($application['gpa'] ?? 'N/A'); ?></p>
                            <p><strong>Status:</strong> <span class="status <?php echo $application['status']; ?>"><?php echo ucfirst($application['status']); ?></span></p>
                            <p><strong>Submitted:</strong> <?php echo date('M j, Y g:i A', strtotime($application['created_at'])); ?></p>
                        </div>
                    </div>

                    <div style="margin:20px 0; padding:20px; border-top:1px solid #e5e7eb;">
                        <h4 class="bold-text">Uploaded Documents</h4>
                        <p class="subtext">Student's certified grades from registrar</p>
                        <a href="view_file.php?student_id=<?php echo urlencode($application['student_id']); ?>" target="_blank" class="action-btn" style="display:inline-block; padding:10px 20px; background:#e07b2a; color:white; text-decoration:none; border-radius:15px; margin-top:10px;">View Uploaded File</a>
                    </div>


                    <?php if ($application['status'] == 'under-review'): ?>
                        <div style="margin:20px 0; padding:20px; border:1px solid #e5e7eb; border-radius:8px; background:#f9fafb;">
                            <h4 class="bold-text">Review Decision</h4>
                            <p class="subtext">Please review the student's application and make a decision:</p>
                            
                            <div style="display:flex; gap:12px; margin-top:16px;">
                                <form method="post" style="display:inline;">
                                    <input type="hidden" name="action" value="accept">
                                    <button type="submit" class="approve-btn" onclick="return confirm('Accept this application?')">Accept Application</button>
                                </form>
                                
                                <button type="button" class="reject-btn" onclick="showRejectForm()">Reject Application</button>
                            </div>
                            
                            <div id="rejectForm" style="display:none; margin-top:20px; padding:20px; border:1px solid #ef4444; border-radius:8px; background:#fef2f2;">
                                <form method="post">
                                    <input type="hidden" name="action" value="reject">
                                    <h5 style="margin:0 0 15px 0; color:#dc2626;">Reason for Rejection:</h5>
                                    <div style="margin-bottom:15px;">
                                        <label style="display:flex; align-items:center; margin-bottom:8px; cursor:pointer;">
                                            <input type="radio" name="rejection_reason" value="Did not reach required GPA" style="margin-right:8px;">
                                            • Did not reach required GPA
                                        </label>
                                        <label style="display:flex; align-items:center; margin-bottom:8px; cursor:pointer;">
                                            <input type="radio" name="rejection_reason" value="Lack of required units" style="margin-right:8px;">
                                            • Lack of required units
                                        </label>
                                        <label style="display:flex; align-items:center; margin-bottom:8px; cursor:pointer;">
                                            <input type="radio" name="rejection_reason" value="others" style="margin-right:8px;" onchange="toggleCustomReason()">
                                            • Others (specify below)
                                        </label>
                                    </div>
                                    <div id="customReasonDiv" style="display:none; margin-bottom:15px;">
                                        <input type="text" name="custom_reason" id="customReason" placeholder="Please specify the reason" style="width:100%; padding:8px; border:1px solid #ddd; border-radius:4px;">
                                    </div>
                                    <div style="display:flex; gap:10px;">
                                        <button type="submit" class="reject-btn" onclick="return confirm('Reject this application with the selected reason?')">Confirm Rejection</button>
                                        <button type="button" class="btn" onclick="hideRejectForm()">Cancel</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php else: ?>
                        <div style="margin:20px 0; padding:20px; border:1px solid #e5e7eb; border-radius:8px; background:#f9fafb;">
                            <h4 class="bold-text">Application Status</h4>
                            <p>This application has been <strong><?php echo $application['status']; ?></strong>.</p>
                            <?php if ($application['status'] == 'rejected' && !empty($application['rejection_reason'])): ?>
                                <div style="margin-top:15px; padding:15px; background:#fee2e2; border:1px solid #fecaca; border-radius:8px;">
                                    <h5 style="color:#dc2626; margin:0 0 10px 0;">Rejection Reason:</h5>
                                    <p style="margin:0; color:#991b1b;"><?php echo htmlspecialchars($application['rejection_reason']); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="card">
                    <p>Application not found.</p>
                </div>
            <?php endif; ?>
        </section>
    </main>
</body>
<script>
function showRejectForm() {
    document.getElementById('rejectForm').style.display = 'block';
}

function hideRejectForm() {
    document.getElementById('rejectForm').style.display = 'none';
    document.querySelectorAll('input[name="rejection_reason"]').forEach(r => r.checked = false);
    document.getElementById('customReason').value = '';
    document.getElementById('customReasonDiv').style.display = 'none';
}

function toggleCustomReason() {
    const othersRadio = document.querySelector('input[name="rejection_reason"][value="others"]');
    const customDiv = document.getElementById('customReasonDiv');
    const customInput = document.getElementById('customReason');
    
    if (othersRadio.checked) {
        customDiv.style.display = 'block';
        customInput.required = true;
    } else {
        customDiv.style.display = 'none';
        customInput.required = false;
        customInput.value = '';
    }
}

// Add change listeners to all radio buttons
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('input[name="rejection_reason"]').forEach(radio => {
        radio.addEventListener('change', toggleCustomReason);
    });
});
</script>
</html>