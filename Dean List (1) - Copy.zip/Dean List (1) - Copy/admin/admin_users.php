<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Admin check
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header("Location: admin_login.php");
    exit();
}

function asset($file) {
    $base = dirname($_SERVER['SCRIPT_NAME']);
    if ($base === '/' || $base === '\\' || $base === '.') $base = '';
    return ($base === '' ? '' : rtrim($base, '/')) . '/' . ltrim($file, '/');
}

$db = (new Database())->getConnection();

// --- Predefined course codes and full names ---
$predefinedCourses = [
    'BSIT' => 'Bachelor of Science in Information Technology',
    'BSCS' => 'Bachelor of Science in Computer Science',
    'BSIS' => 'Bachelor of Science in Information Systems',
];

// Read filters/sorting from GET and validate
$roleFilter = $_GET['role'] ?? 'all';
$courseFilter = $_GET['course'] ?? 'all';
$sortBy = $_GET['sort_by'] ?? 'registered';
$orderDir = strtoupper($_GET['order'] ?? 'DESC');

$allowedSort = [
    'name' => "COALESCE(sp.full_name, u.email)",
    'student_id' => "sp.student_id",
    'registered' => "u.created_at"
];
if (!array_key_exists($sortBy, $allowedSort)) {
    $sortBy = 'registered';
}
$orderDir = ($orderDir === 'ASC') ? 'ASC' : 'DESC';

// Get search parameter
$searchFilter = $_GET['search'] ?? '';

$coursesFromDB = [];
try {
    $courseStmt = $db->prepare("SELECT DISTINCT course FROM students WHERE course IS NOT NULL AND course <> '' ORDER BY course ASC");
    $courseStmt->execute();
    $coursesFromDB = $courseStmt->fetchAll(PDO::FETCH_COLUMN);
} catch (PDOException $e) {
    // ignore error, leave coursesFromDB empty
}

$allCourseCodes = array_values(array_unique(array_merge(array_keys($predefinedCourses), $coursesFromDB)));

$allowedSort = [
    'name' => "s.full_name",
    'student_id' => "s.student_id",
    'registered' => "s.created_at"
];

// Build WHERE clause and params
$where = [];
$params = [];

if ($courseFilter !== 'all' && $courseFilter !== '') {
    $where[] = "s.course = ?";
    $params[] = $courseFilter;
}

if (!empty($searchFilter)) {
    $where[] = "(s.full_name LIKE ? OR s.student_id LIKE ? OR s.course LIKE ?)";
    $searchParam = '%' . $searchFilter . '%';
    $params[] = $searchParam;
    $params[] = $searchParam;
    $params[] = $searchParam;
}

$whereSql = '';
if (count($where) > 0) {
    $whereSql = 'WHERE ' . implode(' AND ', $where);
}

$orderSql = $allowedSort[$sortBy] . ' ' . $orderDir;
$sql = "
    SELECT s.student_id, s.full_name, s.course, s.year_level, s.created_at
    FROM students s
    $whereSql
    ORDER BY $orderSql
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

function qs(array $overrides = []) {
    $q = array_merge($_GET, $overrides);
    return '?' . http_build_query($q);
}

function course_label($code, $predefinedCourses) {
    if (!$code) return '—';
    if (isset($predefinedCourses[$code])) return $predefinedCourses[$code];
    return $code;
}

$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Manage Users - Admin</title>
  <!-- main admin stylesheet -->
  <link rel="stylesheet" href="<?php echo asset('admin.css'); ?>" />
  <style>

  </style>
</head>
<body>

  <header class="admin-header">
    <div class="header-content">
        <h1 class="portal-title"><a href="<?php echo asset('admin_homepage.php'); ?>">Admin Portal</a></h1>

        <nav class="main-nav" role="menubar" aria-label="Main navigation">
            <a role="menuitem" href="<?php echo asset('admin_homepage.php'); ?>" class="<?php echo $currentPage === 'admin_homepage.php' ? 'active' : ''; ?>">Home</a>
            <a role="menuitem" href="<?php echo asset('admin_applications.php'); ?>" class="<?php echo $currentPage === 'admin_applications.php' ? 'active' : ''; ?>">Status</a>
            <a role="menuitem" href="<?php echo asset('../shared/rankings.php'); ?>" class="<?php echo $currentPage === 'rankings.php' ? 'active' : ''; ?>">Rankings</a>
            <a role="menuitem" href="<?php echo asset('admin_users.php'); ?>" class="<?php echo $currentPage === 'admin_users.php' ? 'active' : ''; ?>">Manage Users</a>
            <a role="menuitem" href="<?php echo asset('admin_reports.php'); ?>" class="<?php echo $currentPage === 'admin_reports.php' ? 'active' : ''; ?>">Reports</a>
        </nav>

        <div class="user-nav" aria-label="User area">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['admin'] ?? 'Admin'); ?></span>
            <a href="<?php echo asset('admin_logout.php'); ?>">Logout</a>
        </div>
    </div>
  </header>

  <main class="applications-container page-container" role="main">
    <div class="card" style="background-color: white;">
      <?php if (isset($_GET['deleted'])): ?>
        <div style="padding:12px; margin-bottom:12px; background:#10b981; color:white; border-radius:8px;">
          Student deleted successfully!
        </div>
      <?php endif; ?>
      <?php if (isset($_GET['error'])): ?>
        <div style="padding:12px; margin-bottom:12px; background:#ef4444; color:white; border-radius:8px;">
          Error: Failed to delete student. Please try again.
        </div>
      <?php endif; ?>
      <?php if (isset($_SESSION['edit_error'])): ?>
        <div style="padding:12px; margin-bottom:12px; background:#ef4444; color:white; border-radius:8px;">
          <?php echo htmlspecialchars($_SESSION['edit_error']); unset($_SESSION['edit_error']); ?>
        </div>
      <?php endif; ?>
      <h2 style="color: #2e55a6;">Manage Students</h2>
      <p class="muted" style="margin-bottom:12px;">Search, filter, and manage student accounts.</p>

      <form method="get" class="filters-section"  style="background-color: #e8f6f9; margin-bottom: 1em;" id="filterForm" aria-label="Student filters">
        <div class="control">
          <label for="search">Search</label>
          <input type="text" id="search" name="search" placeholder="Search by name, ID, or course" value="<?php echo htmlspecialchars($searchFilter); ?>" style="padding:8px; border:1px solid #ddd; border-radius:4px; width:200px;">
        </div>

        <div class="control" id="courseControl">
          <label for="course">Course</label>
          <select id="course" name="course" aria-label="Course filter">
            <option value="all" <?php echo $courseFilter === 'all' ? 'selected' : ''; ?>>All Courses</option>
            <?php foreach ($allCourseCodes as $code): ?>
              <option value="<?php echo htmlspecialchars($code); ?>" <?php echo $courseFilter === $code ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($predefinedCourses[$code] ?? $code); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="control">
          <label for="sort_by">Sort by</label>
          <select id="sort_by" name="sort_by" aria-label="Sort by">
            <option value="name" <?php echo $sortBy === 'name' ? 'selected' : ''; ?>>Name (A → Z)</option>
            <option value="student_id" <?php echo $sortBy === 'student_id' ? 'selected' : ''; ?>>Student Number</option>
            <option value="registered" <?php echo $sortBy === 'registered' ? 'selected' : ''; ?>>Date Registered</option>
          </select>
        </div>

        <div class="control">
          <label for="order">Order</label>
          <select id="order" name="order" aria-label="Order direction">
            <option value="ASC" <?php echo $orderDir === 'ASC' ? 'selected' : ''; ?>>Ascending</option>
            <option value="DESC" <?php echo $orderDir === 'DESC' ? 'selected' : ''; ?>>Descending</option>
          </select>
        </div>

        <div style="display:flex; align-items:flex-end; gap:8px;">
          <button type="submit" class="clear-filters" style="background-color: #ffffffd7;">Apply</button>
          <a href="admin_users.php" class="clear-filters" style="background-color: #ffffffd7;">Reset</a>
        </div>
      </form>

      <?php if (count($students) === 0): ?>
        <div class="empty">No students found for the selected filters.</div>
      <?php else: ?>
        <div style="overflow:auto;">
          <table id="usersTable" aria-label="Users table">
            <thead>
              <tr>
                <th>#</th>
                <th>Student ID</th>
                <th>Full Name</th>
                <th>Course</th>
                <th>Year Level</th>
                <th>Registered</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($students as $i => $s): ?>
                <tr id="student-row-<?php echo htmlspecialchars($s['student_id']); ?>" class="<?php echo $i % 2 ? 'table-row-alt' : ''; ?>">
                  <td><?php echo $i + 1; ?></td>
                  <td><?php echo htmlspecialchars($s['student_id']); ?></td>
                  <td><?php echo htmlspecialchars($s['full_name']); ?></td>
                  <td><?php echo htmlspecialchars(course_label($s['course'], $predefinedCourses)); ?></td>
                  <td><?php echo htmlspecialchars($s['year_level']); ?></td>
                  <td class="small"><?php echo htmlspecialchars($s['created_at']); ?></td>
                  <td>
                    <form method="post" action="delete_student.php" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete student: <?php echo htmlspecialchars($s['full_name']); ?> (<?php echo htmlspecialchars($s['student_id']); ?>)? This action cannot be undone.');">
                      <input type="hidden" name="student_id" value="<?php echo htmlspecialchars($s['student_id']); ?>">
                      <button type="submit" class="clear-filters" style="background-color: #b32f2fff; color:white">Delete</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </main>

  <!-- Confirmation modal (non-invasive) -->
  <div class="modal-backdrop" id="confirmDeleteModal" role="dialog" aria-modal="true" aria-labelledby="confirmDeleteTitle">
    <div class="modal" role="document" aria-live="polite">
      <h3 id="confirmDeleteTitle">Confirm user deletion</h3>
      <p class="muted">Are you sure you want to permanently delete this user and all associated information? This action cannot be undone.</p>
      <div><strong id="confirmDeleteEmail">user@example.com</strong></div>
      <div class="actions" style="margin-top:12px;">
        <button type="button" class="btn-cancel" id="cancelDeleteBtn">Cancel</button>
        <button type="button" class="btn-delete-confirm" id="confirmDeleteBtn">Delete user</button>
      </div>
    </div>
  </div>

  <!-- Export API endpoint path for the JS to use -->
  <script>
    window.DELETE_USER_API = "admin_delete_user.php";
  </script>

  <script src="<?php echo asset('admin_users.js'); ?>"></script>
  <script>
  // Backup inline delete functionality in case external JS fails
  document.addEventListener('DOMContentLoaded', function() {
      var deleteButtons = document.querySelectorAll('.delete-user-btn');
      deleteButtons.forEach(function(btn) {
          btn.addEventListener('click', function(e) {
              e.preventDefault();
              var studentId = this.getAttribute('data-student-id');
              var studentName = this.getAttribute('data-student-name');
              
              if (confirm('Are you sure you want to delete student: ' + studentName + ' (' + studentId + ')? This action cannot be undone.')) {
                  fetch('admin_delete_user.php', {
                      method: 'POST',
                      headers: {'Content-Type': 'application/json'},
                      body: JSON.stringify({student_id: studentId})
                  })
                  .then(response => response.json())
                  .then(data => {
                      if (data.success) {
                          alert('Student deleted successfully!');
                          location.reload();
                      } else {
                          alert('Error: ' + (data.message || 'Failed to delete student'));
                      }
                  })
                  .catch(error => {
                      alert('Network error. Please try again.');
                  });
              }
          });
      });
  });
  </script>
</body>
</html>
