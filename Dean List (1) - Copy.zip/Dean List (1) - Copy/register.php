<?php
session_start();
require_once 'config/database.php';
require_once 'config/email_config.php';

$message = '';
$step = 'register'; // 'register' or 'verify'

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['action'] == 'send_verification') {
        $email = trim($_POST['email']);
        $full_name = trim($_POST['full_name']);
        $student_id = trim($_POST['student_id']);
        $password = $_POST['password'];
        $course = $_POST['course'];
        $year_level = $_POST['year_level'];
        
        if (empty($email) || empty($full_name) || empty($student_id) || empty($password)) {
            $message = 'All fields are required.';
        } else {
            try {
                $db = (new Database())->getConnection();
                
                if (!$db) {
                    $message = 'Database connection failed.';
                } else {
                    // Check if email or student ID already exists
                    $checkStmt = $db->prepare("SELECT COUNT(*) FROM users WHERE email = ? OR student_id = ?");
                    $checkStmt->execute([$email, $student_id]);
                    
                    if ($checkStmt->fetchColumn() > 0) {
                        $message = 'Email or Student ID already registered.';
                    } else {
                        // Generate 6-digit verification code
                        $verification_code = sprintf('%06d', mt_rand(0, 999999));
                        
                        // Store student data temporarily
                        $student_data = json_encode([
                            'email' => $email,
                            'full_name' => $full_name,
                            'student_id' => $student_id,
                            'password' => $password,
                            'course' => $course,
                            'year_level' => $year_level
                        ]);
                        
                        // Clear any existing verification for this email
                        $deleteStmt = $db->prepare("DELETE FROM email_verifications WHERE email = ?");
                        $deleteStmt->execute([$email]);
                        
                        // Insert new verification record
                        $insertStmt = $db->prepare("INSERT INTO email_verifications (email, verification_code, student_data) VALUES (?, ?, ?)");
                        $insertStmt->execute([$email, $verification_code, $student_data]);
                        
                        // Try to send verification email
                        $emailService = new EmailConfig();
                        $emailSent = false;
                        
                        // Check if we're running locally (no email server)
                        if ($_SERVER['HTTP_HOST'] === 'localhost' || strpos($_SERVER['HTTP_HOST'], '127.0.0.1') !== false) {
                            // Local development - always show code
                            $_SESSION['verification_email'] = $email;
                            $_SESSION['display_code'] = $verification_code;
                            $step = 'verify';
                            $message = 'Running locally - Your verification code is: ' . $verification_code;
                        } else {
                            // Try to send email on live server
                            if ($emailService->sendVerificationEmail($email, $verification_code, $full_name)) {
                                $_SESSION['verification_email'] = $email;
                                $step = 'verify';
                                $message = 'Verification code sent to your email!';
                                $emailSent = true;
                            } else {
                                // Email failed, show code as fallback
                                $_SESSION['verification_email'] = $email;
                                $_SESSION['display_code'] = $verification_code;
                                $step = 'verify';
                                $message = 'Email service unavailable. Your verification code is: ' . $verification_code;
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                error_log("Registration error: " . $e->getMessage());
                $message = 'Registration error occurred. Please try again.';
            }
        }
    }
    
    if ($_POST['action'] == 'verify_code') {
        $email = $_SESSION['verification_email'] ?? '';
        $entered_code = trim($_POST['verification_code']);
        
        if (empty($entered_code)) {
            $message = 'Please enter the verification code.';
            $step = 'verify';
        } else {
            try {
                $db = (new Database())->getConnection();
                
                // Check verification code (within 15 minutes)
                $verifyStmt = $db->prepare("
                    SELECT verification_code, student_data 
                    FROM email_verifications 
                    WHERE email = ? AND created_at > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
                ");
                $verifyStmt->execute([$email]);
                $verification = $verifyStmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$verification) {
                    $message = 'Verification code expired. Please register again.';
                    unset($_SESSION['verification_email']);
                    $step = 'register';
                } elseif ($verification['verification_code'] !== $entered_code) {
                    $message = 'Invalid verification code. Please try again.';
                    $step = 'verify';
                } else {
                    // Code is valid, create the account
                    $student_data = json_decode($verification['student_data'], true);
                    
                    $db->beginTransaction();
                    
                    // Insert into users table
                    $userStmt = $db->prepare("INSERT INTO users (email, password, role, student_id) VALUES (?, ?, 'student', ?)");
                    $userStmt->execute([$student_data['email'], $student_data['password'], $student_data['student_id']]);
                    
                    // Insert into students table
                    $studentStmt = $db->prepare("INSERT INTO students (student_id, full_name, course, year_level) VALUES (?, ?, ?, ?)");
                    $studentStmt->execute([$student_data['student_id'], $student_data['full_name'], $student_data['course'], $student_data['year_level']]);
                    
                    // Clean up verification record
                    $deleteStmt = $db->prepare("DELETE FROM email_verifications WHERE email = ?");
                    $deleteStmt->execute([$email]);
                    
                    $db->commit();
                    
                    unset($_SESSION['verification_email']);
                    unset($_SESSION['display_code']);
                    $message = 'Registration successful! You can now login.';
                    $step = 'success';
                }
            } catch (Exception $e) {
                $db->rollBack();
                $message = 'Verification error: ' . $e->getMessage();
                $step = 'verify';
            }
        }
    }
}

// If returning to verify step
if (isset($_SESSION['verification_email']) && $step == 'register') {
    $step = 'verify';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration - Dean's List</title>
    <link rel="stylesheet" href="login.css">
    <style>
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: 500;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            background: #f8f9fa;
            box-sizing: border-box;
        }
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #2e55a6;
            background: #fff;
        }
        .verification-input {
            text-align: center;
            font-size: 24px;
            letter-spacing: 5px;
            font-weight: bold;
        }
        .message {
            padding: 12px;
            border-radius: 8px;
            margin: 15px 0;
            font-weight: 500;
        }
        .message.success {
            background: #10b981;
            color: white;
        }
        .message.error {
            background: #ef4444;
            color: white;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            color: #2e55a6;
            text-decoration: none;
            font-weight: 500;
        }
        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="background-blur"></div>
    
    <header>
        <div class="logos">
            <img src="resource/logo.png" alt="LSPU Logo" class="logo">
            <img src="resource/ccs_logo.png" alt="CCS Logo" class="logo">
        </div>
        <h1>DEAN'S LIST APPLICATION</h1>
    </header>

    <main style="display:flex; justify-content:center; padding-top:40px;">
        <?php if ($step == 'register'): ?>
        <!-- Registration Form -->
        <section class="portal" style="max-width:500px; width:100%;">
            <div class="icon">📧</div>
            <h2>Student Registration</h2>
            <p>Create your account to apply for Dean's List</p>

            <?php if ($message): ?>
                <div class="message <?php echo strpos($message, 'sent') !== false || strpos($message, 'successful') !== false ? 'success' : 'error'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="post" action="">
                <input type="hidden" name="action" value="send_verification">
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input id="email" name="email" type="email" placeholder="your.email@lspu.edu.ph" required>
                </div>

                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input id="full_name" name="full_name" type="text" placeholder="Juan Dela Cruz" required>
                </div>

                <div class="form-group">
                    <label for="student_id">Student ID</label>
                    <input id="student_id" name="student_id" type="text" placeholder="2024-00001" required>
                </div>

                <div class="form-group">
                    <label for="course">Course</label>
                    <select id="course" name="course" required>
                        <option value="">Select Course</option>
                        <option value="BSIT">Bachelor of Science in Information Technology</option>
                        <option value="BSCS">Bachelor of Science in Computer Science</option>
                        <option value="BSIS">Bachelor of Science in Information Systems</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="year_level">Year Level</label>
                    <select id="year_level" name="year_level" required>
                        <option value="">Select Year</option>
                        <option value="1">1st Year</option>
                        <option value="2">2nd Year</option>
                        <option value="3">3rd Year</option>
                        <option value="4">4th Year</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input id="password" name="password" type="password" placeholder="Create a password" required>
                </div>

                <button type="submit" class="btn student-btn">Send Verification Code</button>
            </form>

            <div class="back-link">
                Already have an account? <a href="index.php">Login here</a>
            </div>
        </section>

        <?php elseif ($step == 'verify'): ?>
        <!-- Verification Form -->
        <section class="portal" style="max-width:420px; width:100%;">
            <div class="icon">🔐</div>
            <h2>Email Verification</h2>
            <p>Enter the 6-digit code <?php echo isset($_SESSION['display_code']) ? 'shown below' : 'sent to your email'; ?></p>

            <?php if (isset($_SESSION['display_code'])): ?>
                <div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 8px; margin: 15px 0; text-align: center;">
                    <p style="margin: 0 0 10px 0; color: #856404;"><strong>Your verification code:</strong></p>
                    <h2 style="margin: 0; color: #2e55a6; font-size: 28px; letter-spacing: 3px;"><?php echo $_SESSION['display_code']; ?></h2>
                </div>
            <?php endif; ?>

            <?php if ($message): ?>
                <div class="message <?php echo strpos($message, 'sent') !== false ? 'success' : 'error'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="post" action="">
                <input type="hidden" name="action" value="verify_code">
                
                <div class="form-group">
                    <label for="verification_code">Verification Code</label>
                    <input id="verification_code" name="verification_code" type="text" placeholder="000000" maxlength="6" class="verification-input" required>
                </div>

                <button type="submit" class="btn student-btn">Verify & Complete Registration</button>
            </form>

            <div class="back-link">
                <a href="register.php">← Back to Registration</a>
            </div>
        </section>

        <?php elseif ($step == 'success'): ?>
        <!-- Success Message -->
        <section class="portal" style="max-width:420px; width:100%;">
            <div class="icon">✅</div>
            <h2>Registration Complete!</h2>
            <p>Your account has been successfully created and verified.</p>

            <div class="message success">
                <?php echo htmlspecialchars($message); ?>
            </div>

            <a href="index.php" class="btn student-btn" style="text-decoration:none; display:block; text-align:center;">
                Login to Your Account
            </a>
        </section>
        <?php endif; ?>
    </main>
</body>
</html>