<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Check if student is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../student/student_login.php');
    exit();
}

$db = (new Database())->getConnection();
$error = '';
$success = '';

// Handle file upload
function handleFileUpload($inputName, $uploadDir, &$errorMessage) {
    $errorMessage = '';
    if (!isset($_FILES[$inputName])) return null;
    
    $f = $_FILES[$inputName];
    if ($f['error'] !== UPLOAD_ERR_OK) {
        if ($f['error'] === UPLOAD_ERR_NO_FILE) return null;
        $errorMessage = 'File upload error.';
        return null;
    }
    
    $maxBytes = 30 * 1024 * 1024; // 30MB
    if ($f['size'] > $maxBytes) {
        $errorMessage = 'File too large. Max 30MB.';
        return null;
    }
    
    $allowedExt = ['jpg','jpeg','png','pdf'];
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt)) {
        $errorMessage = 'Invalid file type. Allowed: JPG, PNG, PDF.';
        return null;
    }
    
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $newName = uniqid('app_') . '.' . $ext;
    $dest = $uploadDir . '/' . $newName;
    
    if (move_uploaded_file($f['tmp_name'], $dest)) {
        return 'uploads/applications/' . $newName;
    }
    
    $errorMessage = 'Failed to save uploaded file.';
    return null;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subjects = $_POST['subject'] ?? [];
    $grades = $_POST['grade'] ?? [];
    $units = $_POST['units'] ?? [];
    
    // Process grades
    $rows = [];
    $max = max(count($subjects), count($grades), count($units));
    for ($i = 0; $i < $max; $i++) {
        $sub = trim($subjects[$i] ?? '');
        $gr = trim($grades[$i] ?? '');
        $un = intval($units[$i] ?? 0);
        if ($sub !== '' && $gr !== '' && $gr !== 'Select grade' && $un > 0) {
            $rows[] = ['subject' => $sub, 'grade' => (float)$gr, 'units' => $un];
        }
    }
    
    if (count($rows) === 0) {
        $error = 'Please add at least one course with valid grade and units.';
    } else {
        // Handle file upload
        $uploadDir = __DIR__ . '/../uploads/applications';
        $uploadErr = '';
        $savedFilePath = handleFileUpload('fileUpload', $uploadDir, $uploadErr);
        
        if ($uploadErr) {
            $error = $uploadErr;
        } elseif ($savedFilePath === null) {
            $error = 'Please upload your certified grades from the registrar.';
        } else {
            // Calculate GPA and total units
            $sumWeighted = 0.0;
            $sumUnits = 0;
            foreach ($rows as $r) {
                $sumWeighted += $r['grade'] * $r['units'];
                $sumUnits += $r['units'];
            }
            $gpa = round($sumWeighted / $sumUnits, 3);
            $totalUnits = $sumUnits;
            
            try {
                // Get current semester and academic year
                $semQuery = "SELECT semID FROM semester ORDER BY semID DESC LIMIT 1";
                $semStmt = $db->prepare($semQuery);
                $semStmt->execute();
                $semID = $semStmt->fetchColumn();
                
                $acadQuery = "SELECT acadID FROM acad_year ORDER BY acadID DESC LIMIT 1";
                $acadStmt = $db->prepare($acadQuery);
                $acadStmt->execute();
                $acadID = $acadStmt->fetchColumn();
                
                // Insert application
                $insertSQL = "INSERT INTO applications (user_id, student_id, gpa, total_units, semID, acadID, file_path, status, created_at) 
                             VALUES (?, ?, ?, ?, ?, ?, ?, 'under-review', NOW())";
                $stmt = $db->prepare($insertSQL);
                $stmt->execute([$_SESSION['user_id'], $_SESSION['student_id'], $gpa, $totalUnits, $semID, $acadID, $savedFilePath]);
                
                $success = 'Application submitted successfully!';
            } catch (Exception $e) {
                $error = 'Error submitting application: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Dean's Lister Application</title>
    <link rel="stylesheet" href="../admin/admin.css">
    <style>
        .grade-row {
            display: grid;
            grid-template-columns: 1fr 150px 80px 40px;
            gap: 10px;
            align-items: center;
        }
        
        @media (max-width: 768px) {
            .grade-row {
                grid-template-columns: 1fr !important;
                gap: 8px !important;
            }
            .grade-row input,
            .grade-row select {
                width: 100% !important;
            }
            .grade-row button {
                width: 100% !important;
                padding: 10px !important;
            }
        }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-links"><a href="../student/student_homepage.php">Dean's Lister Application</a></div>
    </nav>

    <main class="applications-container">
        <div><a href="../student/student_homepage.php" class="back">Back to Dashboard</a></div>

        <section class="applications-list">
            <h3 class="bold-text">Dean's Lister Application Details</h3>
            
            <?php if ($error): ?>
                <div style="color:#fff;background:#ef4444;padding:10px;border-radius:8px;margin-bottom:12px;">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div style="color:#fff;background:#10b981;padding:10px;border-radius:8px;margin-bottom:12px;">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <form id="applicationForm" method="POST" enctype="multipart/form-data">
                <div style="margin-top:1rem;">
                    <label style="display:block;font-weight:600;margin-bottom:8px" class="bold-text">Student ID</label>
                    <input type="text" value="<?php echo htmlspecialchars($_SESSION['student_id']); ?>" readonly 
                           style="width:100%;padding:12px;border-radius:8px;border:1px solid #e5e7eb;background:#f3f4f6;color:#6b7280;">
                </div>

                <div style="margin-top:1rem;">
                    <label style="display:block;font-weight:600;margin-bottom:8px" class="bold-text">Full Name</label>
                    <input type="text" value="<?php echo htmlspecialchars($_SESSION['full_name']); ?>" readonly 
                           style="width:100%;padding:12px;border-radius:8px;border:1px solid #e5e7eb;background:#f3f4f6;color:#6b7280;">
                </div>

                <div style="margin-top:1rem;">
                    <label style="display:block;font-weight:600;margin-bottom:8px" class="bold-text">Course</label>
                    <input type="text" value="<?php echo htmlspecialchars($_SESSION['course']); ?>" readonly 
                           style="width:100%;padding:12px;border-radius:8px;border:1px solid #e5e7eb;background:#f3f4f6;color:#6b7280;">
                </div>

                <div style="margin-top:18px;">
                    <label style="font-weight:600;" class="bold-text">Enter your course grades. Only grades 2.0 and below qualify for Dean's List consideration.</label>

                    <div id="gradesList" style="margin-top:12px;display:flex;flex-direction:column;gap:10px">
                    </div>

                    <div style="margin-top:12px;">
                        <button id="addGradeBtn" class="btn" style="font-size: 13px; padding: 5px;" type="button">+ Add Another Grade</button>
                    </div>
                </div>

                <div style="margin-top:18px;">
                    <h4 style="margin-bottom:8px" class="bold-text">Certified Grades from Registrar</h4>
                    <p class="subtext">Upload a copy of your official grades certified by the registrar. Accepted formats: JPEG, PNG, PDF (Max 30MB)</p>

                    <label for="fileUpload" id="fileLabel" style="display:block;margin-top:12px;border:2px dashed #e5e7eb;padding:16px;border-radius:8px;text-align:center;color:#6b7280;cursor:pointer">
                        <input id="fileUpload" name="fileUpload" type="file" accept="image/*,.pdf" required style="display:none">
                        <div>Click to upload or drag and drop</div>
                        <div style="font-size:12px;margin-top:6px;color:#9ca3af">JPEG, PNG or PDF (MAX. 30MB)</div>
                        <div id="fileNameDisplay" style="margin-top:8px;font-size:13px;color:#111827;"></div>
                    </label>
                </div>

                <div style="display:flex;justify-content:flex-end;gap:12px;margin-top:20px">
                    <a href="../student/student_homepage.php" class="btn">Cancel</a>
                    <button id="submitBtn" class="submit-application-btn" type="submit">Submit Dean's Lister Application</button>
                </div>
            </form>
        </section>
    </main>
</body>
<script>
// Dynamic grade rows + file name display + form validation
(function(){
    const gradesList = document.getElementById('gradesList');
    const addBtn = document.getElementById('addGradeBtn');
    const submitBtn = document.getElementById('submitBtn');
    const appForm = document.getElementById('applicationForm');
    const fileInput = document.getElementById('fileUpload');
    const fileLabel = document.getElementById('fileLabel');
    const fileNameDisplay = document.getElementById('fileNameDisplay');

    function makeGradeRow(){
        const row = document.createElement('div');
        row.className = 'grade-row';
        row.style.display = 'grid';
        row.style.gridTemplateColumns = '1fr 150px 80px 40px';
        row.style.gap = '10px';
        row.style.alignItems = 'center';

        const subj = document.createElement('input');
        subj.type = 'text';
        subj.name = 'subject[]';
        subj.placeholder = 'Subject code or name';
        subj.style.padding = '10px';
        subj.style.borderRadius = '8px';
        subj.style.border = '1px solid #e5e7eb';

        const gradeSel = document.createElement('select');
        gradeSel.name = 'grade[]';
        ['Select grade','1.0','1.25','1.5','1.75','2.0'].forEach(g=>{
            const o = document.createElement('option'); 
            o.value = g === 'Select grade' ? '' : g;
            o.textContent = g; 
            gradeSel.appendChild(o);
        });
        gradeSel.style.padding='10px'; 
        gradeSel.style.borderRadius='8px'; 
        gradeSel.style.border='1px solid #e5e7eb';

        const units = document.createElement('select');
        units.name = 'units[]';
        ['Units',1,2,3,4,5,6].forEach(u=>{ 
            const o=document.createElement('option'); 
            o.value = u === 'Units' ? '' : u;
            o.textContent=u; 
            units.appendChild(o); 
        });
        units.style.padding='10px'; 
        units.style.borderRadius='8px'; 
        units.style.border='1px solid #e5e7eb';

        const del = document.createElement('button'); 
        del.type='button'; 
        del.innerHTML='🗑'; 
        del.style.border='none'; 
        del.style.background='transparent'; 
        del.style.cursor='pointer';
        del.style.fontSize='16px';
        del.addEventListener('click', ()=> row.remove());

        row.appendChild(subj); 
        row.appendChild(gradeSel); 
        row.appendChild(units); 
        row.appendChild(del);
        return row;
    }

    addBtn.addEventListener('click', function(e){ 
        e.preventDefault(); 
        gradesList.appendChild(makeGradeRow()); 
    });
    
    // Add initial grade row
    gradesList.appendChild(makeGradeRow());

    // File upload handling
    function setFileNameDisplay(file) {
        if (!file) {
            fileNameDisplay.textContent = '';
            return;
        }
        fileNameDisplay.textContent = file.name + ' (' + Math.round(file.size / 1024) + ' KB)';
        fileNameDisplay.style.color = '#111827';
    }

    fileInput.addEventListener('change', function(e){
        const f = fileInput.files[0];
        setFileNameDisplay(f);
    });

    fileLabel.addEventListener('dragover', (e)=>{ 
        e.preventDefault(); 
        fileLabel.style.borderColor='#4338ca'; 
    });
    
    fileLabel.addEventListener('dragleave', ()=>{ 
        fileLabel.style.borderColor='#e5e7eb'; 
    });
    
    fileLabel.addEventListener('drop', (e)=>{ 
        e.preventDefault(); 
        fileLabel.style.borderColor='#e5e7eb'; 
        const f = e.dataTransfer.files[0]; 
        if (f) {
            try { 
                fileInput.files = e.dataTransfer.files; 
            } catch (err) { 
                // Some browsers restrict programmatic set 
            }
            setFileNameDisplay(f);
        }
    });

    // Form validation
    appForm.addEventListener('submit', function(e){
        const subjects = document.getElementsByName('subject[]');
        const grades = document.getElementsByName('grade[]');
        const units = document.getElementsByName('units[]');
        
        let hasValid = false;
        for (let i = 0; i < subjects.length; i++) {
            const s = subjects[i].value.trim();
            const g = grades[i] ? grades[i].value.trim() : '';
            const u = units[i] ? parseInt(units[i].value,10) : 0;
            if (s !== '' && g !== '' && u > 0) {
                hasValid = true;
                break;
            }
        }
        
        if (!hasValid) {
            e.preventDefault();
            alert('Please add at least one course with a valid grade and units before submitting.');
            return false;
        }
        
        if (!fileInput.files || fileInput.files.length === 0) {
            e.preventDefault();
            alert('Please upload your certified grades from the registrar before submitting.');
            return false;
        }
        
        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';
    });
})();
</script>
</html>