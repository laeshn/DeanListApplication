<?php
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../config/database.php';

// Check if student is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../student/student_login.php');
    exit();
}

$db = (new Database())->getConnection();

// Get student's applications
$stmt = $db->prepare("SELECT * FROM applications WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['user_id']]);
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Function to convert UTC to Philippine Time
function toPHT($utcDateTime) {
    $utc = new DateTime($utcDateTime, new DateTimeZone('UTC'));
    $utc->setTimezone(new DateTimeZone('Asia/Manila'));
    return $utc;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Application Status</title>
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <link rel="stylesheet" href="application_status.css">
</head>
<body>
    <nav style="background: linear-gradient(90deg, #e07b2a 0%, #d66b1a 100%);" class="top-nav">
        <div class="nav-content">
            <div class="nav-links">
                <a href="../student/student_homepage.php" style="color:white; font-weight: 600;">Back to Dashboard</a>
                <span style="color: white;" class="current-page">Application Status</span>
            </div>
        </div>
    </nav>

    <div class="status-container">
        <?php if (empty($applications)): ?>
            <div class="status-card">
                <div class="status-header">
                    <div class="status-icon">📄</div>
                    <div class="status-text">
                        <h1>No Applications Found</h1>
                        <p>You haven't submitted any applications yet</p>
                    </div>
                </div>
                <div class="status-content">
                    <p style="text-align:center; margin:20px 0;">
                        <a href="application.php" style="background:#2563eb; color:white; padding:12px 24px; border-radius:8px; text-decoration:none; font-weight:500;">Submit Your First Application</a>
                    </p>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($applications as $app): ?>
                <div class="status-card">
                    <div class="status-header">
                        <div class="status-icon">📋</div>
                        <div class="status-text">
                            <h1>Application</h1>
                            <p>Submitted on <?php echo toPHT($app['created_at'])->format('M j, Y'); ?></p>
                        </div>
                        <div class="status-badge <?php echo $app['status']; ?>" style="<?php 
                            if ($app['status'] === 'accepted') echo 'background: #16a34a !important; color: white !important;';
                            elseif ($app['status'] === 'rejected') echo 'background: #dc2626 !important; color: white !important;';
                            elseif ($app['status'] === 'under-review') echo 'background: #eab308 !important; color: white !important;';
                        ?>"><?php echo ucfirst(str_replace('-', ' ', $app['status'])); ?></div>
                    </div>
                    
                    <div class="status-content">
                        <div class="details-section">
                            <h2>Application Details</h2>
                            <div class="details-grid">
                                <div class="detail-item">
                                    <label>Student ID</label>
                                    <span><?php echo htmlspecialchars($app['student_id']); ?></span>
                                </div>
                                <div class="detail-item">
                                    <label>GPA</label>
                                    <span><?php echo htmlspecialchars($app['gpa']); ?></span>
                                </div>
                                <div class="detail-item">
                                    <label>Status</label>
                                    <span><?php echo ucfirst(str_replace('-', ' ', $app['status'])); ?></span>
                                </div>
                                <div class="detail-item">
                                    <label>Submitted</label>
                                    <span><?php echo toPHT($app['created_at'])->format('M j, Y g:i A'); ?> PHT</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="timeline-section">
                            <h2>Application Timeline</h2>
                            <div class="timeline">
                                <div class="timeline-item complete">
                                    <div class="timeline-dot" style="background: #ea580c !important; border-color: #ea580c !important;"></div>
                                    <div class="timeline-content">
                                        <h3>Application Submitted</h3>
                                        <time><?php echo toPHT($app['created_at'])->format('M j, Y g:i A'); ?> PHT</time>
                                    </div>
                                </div>
                                <div class="timeline-item <?php 
                                    if ($app['status'] === 'under-review') echo 'under-review';
                                    else echo $app['status'];
                                ?>">
                                    <div class="timeline-dot" style="<?php 
                                        if ($app['status'] === 'accepted') echo 'background: #16a34a !important; border-color: #16a34a !important;';
                                        elseif ($app['status'] === 'rejected') echo 'background: #dc2626 !important; border-color: #dc2626 !important;';
                                        elseif ($app['status'] === 'under-review') echo 'background: white !important; border-color: #e5e7eb !important;';
                                    ?>"></div>
                                    <div class="timeline-content">
                                        <h3><?php 
                                            if ($app['status'] === 'accepted') echo 'Application Accepted';
                                            elseif ($app['status'] === 'rejected') echo 'Application Rejected';
                                            else echo 'Under Review';
                                        ?></h3>
                                        <time><?php 
                                            if ($app['status'] !== 'under-review') {
                                                echo toPHT($app['created_at'])->format('M j, Y g:i A') . ' PHT';
                                            } else {
                                                echo 'In progress...';
                                            }
                                        ?></time>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if ($app['status'] === 'under-review'): ?>
                            <div class="progress-section">
                                <label>Progress</label>
                                <div class="progress-bar">
                                    <div class="progress" style="width: 50%;"></div>
                                </div>
                                <span class="progress-text">50%</span>
                            </div>
                        <?php elseif ($app['status'] === 'rejected'): ?>
                            <div style="background:#fee2e2; color:#dc2626; padding:12px; border-radius:8px; margin-top:16px;">
                                <strong>Application Not Accepted</strong> - Your application was not accepted this time. You may apply again next semester.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>