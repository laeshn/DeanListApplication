<?php
require_once '../config/database.php';

function archiveApplications($semester = null, $academic_year = null) {
    try {
        $db = (new Database())->getConnection();
        
        // Get current semester and academic year if not provided
        if (!$semester || !$academic_year) {
            $semQuery = "SELECT * FROM semester ORDER BY semID DESC LIMIT 1";
            $semStmt = $db->prepare($semQuery);
            $semStmt->execute();
            $semesterData = $semStmt->fetch(PDO::FETCH_ASSOC);
            
            $acadQuery = "SELECT * FROM acad_year ORDER BY acadID DESC LIMIT 1";
            $acadStmt = $db->prepare($acadQuery);
            $acadStmt->execute();
            $acadYearData = $acadStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($semesterData) {
                $semester = $semesterData['semID'] . ' Semester';
            }
            if ($acadYearData) {
                $academic_year = date('Y', strtotime($acadYearData['start_date'])) . '-' . date('Y', strtotime($acadYearData['end_date']));
            }
        }
        
        // Archive applications with their rankings
        $archiveQuery = "
            INSERT INTO rankings_archive 
            (student_id, semester, academic_year, gpa, grades_json, file_path, final_rank, total_students, status, rejection_reason)
            SELECT 
                a.student_id,
                a.semester,
                ?,
                a.gpa,
                a.grades_json,
                a.file_path,
                COALESCE(sr.current_rank, 999) as final_rank,
                COALESCE(sr.total_students, 0) as total_students,
                a.status,
                a.rejection_reason
            FROM applications a
            LEFT JOIN (
                SELECT sr1.student_id,
                       (SELECT COUNT(*) + 1 FROM student_rankings sr2 
                        WHERE sr2.gpa < sr1.gpa AND sr2.semester = sr1.semester AND sr2.academic_year = sr1.academic_year) as current_rank,
                       (SELECT COUNT(*) FROM student_rankings sr3 
                        WHERE sr3.semester = sr1.semester AND sr3.academic_year = sr1.academic_year) as total_students
                FROM student_rankings sr1
                WHERE sr1.academic_year = ?
            ) sr ON sr.student_id = a.student_id
            WHERE a.status IN ('accepted', 'rejected')
        ";
        
        $archiveStmt = $db->prepare($archiveQuery);
        $archiveStmt->execute([$academic_year, $academic_year]);
        $archivedCount = $archiveStmt->rowCount();
        
        // Clear current applications and rankings for new semester
        $db->exec("DELETE FROM applications");
        $db->exec("DELETE FROM student_rankings");
        
        return [
            'success' => true,
            'message' => "Archived $archivedCount applications for $semester, $academic_year",
            'archived_count' => $archivedCount
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Error archiving applications: ' . $e->getMessage()
        ];
    }
}

// If called directly, archive applications
if (basename(__FILE__) == basename($_SERVER['SCRIPT_NAME'])) {
    $result = archiveApplications();
    echo json_encode($result, JSON_PRETTY_PRINT);
}
?>
