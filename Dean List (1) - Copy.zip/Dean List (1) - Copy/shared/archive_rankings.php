<?php
require_once '../config/database.php';

function archiveRankings($semID = null, $acadID = null) {
    try {
        $db = (new Database())->getConnection();
        
        // Get current semID and acadID if not provided
        if (!$semID || !$acadID) {
            // Get the most recent semester that has rankings
            $semQuery = "SELECT DISTINCT sr.semID, sr.acadID 
                        FROM student_rankings sr 
                        ORDER BY sr.semID DESC LIMIT 1";
            $semStmt = $db->prepare($semQuery);
            $semStmt->execute();
            $semData = $semStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($semData) {
                $semID = $semData['semID'];
                $acadID = $semData['acadID'];
            } else {
                return [
                    'success' => false,
                    'message' => 'No rankings found to archive',
                    'archived_count' => 0
                ];
            }
        }
        
        // Check if there are rankings to archive
        $checkStmt = $db->prepare("SELECT COUNT(*) FROM student_rankings WHERE semID = ? AND acadID = ?");
        $checkStmt->execute([$semID, $acadID]);
        $rankingsCount = $checkStmt->fetchColumn();
        
        if ($rankingsCount == 0) {
            return [
                'success' => true,
                'message' => 'No rankings to archive for this semester',
                'archived_count' => 0
            ];
        }
        
        // Archive rankings with proper rank calculation (lower GPA = better rank) grouped by course and year
        $archiveQuery = "
            INSERT INTO rankings_archive 
            (student_id, full_name, course, year_level, semID, acadID, gpa, final_rank)
            SELECT 
                sr.student_id,
                sr.full_name,
                sr.course,
                sr.year_level,
                sr.semID,
                sr.acadID,
                sr.gpa,
                (SELECT COUNT(*) + 1 FROM student_rankings sr2 
                 WHERE CAST(sr2.gpa AS DECIMAL(4,2)) < CAST(sr.gpa AS DECIMAL(4,2)) 
                 AND sr2.semID = sr.semID AND sr2.acadID = sr.acadID 
                 AND sr2.course = sr.course AND sr2.year_level = sr.year_level) as final_rank
            FROM student_rankings sr
            WHERE sr.semID = ? AND sr.acadID = ?
            ORDER BY sr.course ASC, sr.year_level ASC, CAST(sr.gpa AS DECIMAL(4,2)) ASC
        ";
        
        $archiveStmt = $db->prepare($archiveQuery);
        $archiveStmt->execute([$semID, $acadID]);
        $archivedCount = $archiveStmt->rowCount();
        
        // Clear current rankings for the archived semester
        $clearStmt = $db->prepare("DELETE FROM student_rankings WHERE semID = ? AND acadID = ?");
        $clearStmt->execute([$semID, $acadID]);
        
        return [
            'success' => true,
            'message' => "Archived $archivedCount rankings for semID: $semID, acadID: $acadID",
            'archived_count' => $archivedCount
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Error archiving rankings: ' . $e->getMessage()
        ];
    }
}

// If called directly, archive rankings
if (basename(__FILE__) == basename($_SERVER['SCRIPT_NAME'])) {
    $result = archiveRankings();
    echo json_encode($result, JSON_PRETTY_PRINT);
}
?>
