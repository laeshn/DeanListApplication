<?php
require_once '../config/database.php';

function generateRankings($semID = null, $acadID = null) {
    try {
        $db = (new Database())->getConnection();
        
        // Create rankings_archive table if it doesn't exist
        $db->exec("CREATE TABLE IF NOT EXISTS rankings_archive (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id VARCHAR(20),
            full_name VARCHAR(255),
            course VARCHAR(10),
            year_level INT,
            gpa DECIMAL(3,2),
            final_rank INT,
            semID INT,
            acadID INT,
            archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        // Get current semID and acadID if not provided
        if (!$semID || !$acadID) {
            $semQuery = "SELECT semID, acadID FROM semester ORDER BY semID DESC LIMIT 1";
            $semStmt = $db->prepare($semQuery);
            $semStmt->execute();
            $semData = $semStmt->fetch(PDO::FETCH_ASSOC);
            
            if ($semData) {
                $semID = $semData['semID'];
                $acadID = $semData['acadID'];
            } else {
                return [
                    'success' => false,
                    'message' => 'No semester found. Please set a semester first.'
                ];
            }
        }
        
        // Clear existing rankings for this semester
        $clearStmt = $db->prepare("DELETE FROM student_rankings WHERE semID = ? AND acadID = ?");
        $clearStmt->execute([$semID, $acadID]);
        
        // Get accepted applications with their GPAs, ordered by course, year_level, then GPA (ascending = lower is better: 1.0 > 1.25 > 1.5)
        $sql = "
            SELECT a.student_id, a.gpa, a.semID, a.acadID, s.full_name, s.course, s.year_level, a.user_id
            FROM applications a
            JOIN students s ON s.student_id = a.student_id
            WHERE a.status = 'accepted' 
            AND a.gpa IS NOT NULL 
            AND a.gpa != ''
            AND a.semID = ?
            AND a.acadID = ?
            ORDER BY s.course ASC, s.year_level ASC, CAST(a.gpa AS DECIMAL(4,2)) ASC
        ";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$semID, $acadID]);
        $acceptedApps = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Group applications by course and year level
        $groupedApps = [];
        foreach ($acceptedApps as $app) {
            $key = $app['course'] . '_' . $app['year_level'];
            if (!isset($groupedApps[$key])) {
                $groupedApps[$key] = [];
            }
            $groupedApps[$key][] = $app;
        }
        
        // Generate rankings for each course-year group
        foreach ($groupedApps as $group) {
            $rank = 1;
            foreach ($group as $app) {
                $rankChange = 0;
                
                // Check previous semester rank in archive (same acadID, different semID, same course and year)
                try {
                    $prevRankQuery = "SELECT final_rank FROM rankings_archive 
                                     WHERE student_id = ? AND acadID = ? AND semID != ?
                                     AND course = ? AND year_level = ?
                                     ORDER BY semID DESC LIMIT 1";
                    $prevStmt = $db->prepare($prevRankQuery);
                    $prevStmt->execute([$app['student_id'], $acadID, $semID, $app['course'], $app['year_level']]);
                    $prevRank = $prevStmt->fetchColumn();
                    
                    if ($prevRank) {
                        $rankChange = $prevRank - $rank; // positive = improved, negative = declined
                    }
                } catch (Exception $e) {
                    // If archive query fails, just set rank change to 0
                    $rankChange = 0;
                }
                
                $insertSql = "
                    INSERT INTO student_rankings 
                    (student_id, full_name, course, year_level, semID, acadID, gpa, credits, rank_change)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ";
                
                $insertStmt = $db->prepare($insertSql);
                $insertStmt->execute([
                    $app['student_id'],
                    $app['full_name'],
                    $app['course'],
                    $app['year_level'],
                    $semID,
                    $acadID,
                    $app['gpa'],
                    0, // Default credits value
                    $rankChange
                ]);
                
                $rank++;
            }
        }
        
        return [
            'success' => true,
            'message' => "Rankings generated successfully for semID: $semID, acadID: $acadID",
            'total_ranked' => count($acceptedApps)
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Error generating rankings: ' . $e->getMessage()
        ];
    }
}

// If called directly, generate rankings
if (basename(__FILE__) == basename($_SERVER['SCRIPT_NAME'])) {
    $result = generateRankings();
    echo json_encode($result, JSON_PRETTY_PRINT);
}
?>
