<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Admin guard (keep as your other admin pages)
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: admin_login.php');
    exit();
}

// asset helper (keeps your existing helper)
function asset($file) {
    $base = dirname($_SERVER['SCRIPT_NAME']);
    if ($base === '/' || $base === '\\' || $base === '.') {
        $base = '';
    }
    return ($base === '' ? '' : rtrim($base, '/')) . '/' . ltrim($file, '/');
}

// read filters from GET (preserve values when reloading)
$filterSemester = trim((string)($_GET['semester'] ?? ''));
$filterCourse = trim((string)($_GET['course'] ?? ''));
$filterYearLevel = trim((string)($_GET['year_level'] ?? ''));
$filterAcademicYear = trim((string)($_GET['academic_year'] ?? ''));
$search = trim((string)($_GET['q'] ?? ''));

try {
    $db = (new Database())->getConnection();
    
    // Only default to current semester if BOTH semester AND academic year are empty
    // This allows "All Academic Years" to show all data
    if (empty($filterSemester) && empty($filterAcademicYear) && !isset($_GET['academic_year'])) {
        try {
            $currentSemQuery = "SELECT semester_number FROM current_semester ORDER BY id DESC LIMIT 1";
            $currentSemStmt = $db->prepare($currentSemQuery);
            $currentSemStmt->execute();
            $currentSemData = $currentSemStmt->fetch(PDO::FETCH_ASSOC);
            if ($currentSemData) {
                $semNum = $currentSemData['semester_number'];
                $filterSemester = ($semNum == '1' ? '1st' : ($semNum == '2' ? '2nd' : $semNum)) . ' Semester';
            }
        } catch (Exception $e) {
            // Keep empty filter
        }
    }

    // Get courses from database
    $stmt = $db->prepare("
        SELECT DISTINCT course FROM students WHERE course IS NOT NULL ORDER BY course
    ");
    $stmt->execute();
    $courseOptions = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Get year levels from database
    $stmt = $db->prepare("
        SELECT DISTINCT year_level FROM students WHERE year_level IS NOT NULL ORDER BY year_level
    ");
    $stmt->execute();
    $yearLevelOptions = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Get academic years from acad_year table
    $stmt = $db->prepare("
        SELECT DISTINCT academic_year FROM acad_year WHERE academic_year IS NOT NULL ORDER BY academic_year DESC
    ");
    $stmt->execute();
    $academicYearOptions = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $semesterOptions = ['1st Semester', '2nd Semester'];

    // Always show both current and archive data to allow viewing past rankings
    $useArchive = false;
    $showBoth = true; // Always show both to include archive data
    
    $params = [];
    $sql = ""; // Initialize SQL variable
    
    if ($showBoth) {
        // Combined query (current + archive) with JOINs for semester/academic_year
        $sql = "
            SELECT student_id, full_name, course, year_level, semester_number, academic_year, gpa, credits, rank_change, source, final_rank
            FROM (
                -- current rankings
                SELECT sr.student_id, sr.full_name, sr.course, sr.year_level, 
                       CASE WHEN sr.semID % 2 = 1 THEN 1 ELSE 2 END AS semester_number,
                       ay.academic_year, 
                       sr.gpa, 
                       COALESCE(sr.credits, 0) AS credits, 
                       COALESCE(sr.rank_change,0) AS rank_change, 
                       'current' AS source, 
                       NULL AS final_rank
                FROM student_rankings sr
                LEFT JOIN semester sem ON sem.semID = sr.semID
                LEFT JOIN acad_year ay ON ay.acadID = sr.acadID
                UNION ALL
                -- archived rankings
                SELECT ra.student_id, 
                       ra.full_name, 
                       ra.course, 
                       ra.year_level,
                       CASE WHEN ra.semID % 2 = 1 THEN 1 ELSE 2 END AS semester_number,
                       ay.academic_year,
                       ra.gpa,
                       0 as credits,
                       0 AS rank_change, 
                       'archive' AS source, 
                       ra.final_rank
                FROM rankings_archive ra
                LEFT JOIN semester sem ON sem.semID = ra.semID
                LEFT JOIN acad_year ay ON ay.acadID = ra.acadID
            ) AS combined
            WHERE 1=1
        ";

    } elseif ($useArchive) {
        // Query from archive with student info
        $sql = "
            SELECT ra.student_id, ra.full_name, ra.course, ra.year_level,
                   ra.semester, ra.academic_year, ra.gpa,
                   0 as credits,
                   0 as rank_change, ra.final_rank, 'archive' as source
            FROM rankings_archive ra
            WHERE 1=1
        ";
    } else {
        // Query from current rankings
        $sql = "
            SELECT sr.student_id, sr.full_name, sr.course, sr.year_level, 
                   CASE WHEN sr.semID % 2 = 1 THEN 1 ELSE 2 END AS semester_number,
                   ay.academic_year, sr.gpa, COALESCE(sr.credits,0) AS credits,
                   COALESCE(sr.rank_change,0) AS rank_change, NULL AS final_rank, 'current' as source
            FROM student_rankings sr
            LEFT JOIN semester sem ON sem.semID = sr.semID
            LEFT JOIN acad_year ay ON ay.acadID = sr.acadID
            WHERE 1=1
        ";
    }
    
    // Build WHERE conditions for subqueries
    $whereConditions = [];
    if ($filterSemester !== '') {
        $semNum = (strpos($filterSemester, '1st') !== false) ? '1' : '2';
        $whereConditions[] = "semester_number = :semester_num";
        $params[':semester_num'] = $semNum;
    }
    if ($filterCourse !== '') {
        $whereConditions[] = "course = :course";
        $params[':course'] = $filterCourse;
    }
    if ($filterYearLevel !== '') {
        $whereConditions[] = "year_level = :year_level";
        $params[':year_level'] = $filterYearLevel;
    }
    if ($filterAcademicYear !== '') {
        $whereConditions[] = "academic_year = :academic_year";
        $params[':academic_year'] = $filterAcademicYear;
    }
    if ($search !== '') {
        $whereConditions[] = "(student_id LIKE :q1 OR full_name LIKE :q2)";
        $params[':q1'] = '%' . $search . '%';
        $params[':q2'] = '%' . $search . '%';
    }
    
    // Apply WHERE conditions to the outer query
    if (!empty($whereConditions)) {
        $sql .= " AND " . implode(" AND ", $whereConditions);
    }

    // Group by to prevent duplicates
    if ($showBoth) {
        $sql .= " GROUP BY student_id, semester_number, academic_year";
    }

    // Order by GPA ascending (lower is better), then credits desc
    if ($showBoth) {
        $sql .= " ORDER BY academic_year DESC, semester_number, gpa ASC, credits DESC";
    } elseif ($useArchive) {
        $sql .= " ORDER BY ra.final_rank ASC";
    } else {
        $sql .= " ORDER BY gpa ASC, credits DESC";
    }

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch unfiltered data for dashboard stats (without search filter)
    $dashboardParams = [];
    $dashboardSql = $sql;
    // Remove search conditions from dashboard query
    if ($search !== '') {
        // Re-build query without search filter
        $dashboardSql = str_replace(" AND (student_id LIKE :q1 OR full_name LIKE :q2)", "", $dashboardSql);
        // Copy only non-search params
        foreach ($params as $key => $val) {
            if ($key !== ':q1' && $key !== ':q2') {
                $dashboardParams[$key] = $val;
            }
        }
    } else {
        $dashboardParams = $params;
    }
    $dashboardStmt = $db->prepare($dashboardSql);
    $dashboardStmt->execute($dashboardParams);
    $allRows = $dashboardStmt->fetchAll(PDO::FETCH_ASSOC);

    // Compute actual rank from database BEFORE filtering by search
    // Group students by semester, academic year, course, and year level, then assign ranks
    $groupedData = [];
    foreach ($rows as &$r) {
        $key = $r['semester_number'] . '_' . $r['academic_year'] . '_' . $r['course'] . '_' . $r['year_level'];
        if (!isset($groupedData[$key])) {
            $groupedData[$key] = [];
        }
        $groupedData[$key][] = &$r;
    }
    unset($r);

    // Assign ranks within each group (course + year level)
    foreach ($groupedData as $group) {
        // Sort by GPA ascending (lower is better), then by credits descending
        usort($group, function($a, $b) {
            $gpaCompare = floatval($a['gpa']) <=> floatval($b['gpa']);
            if ($gpaCompare !== 0) return $gpaCompare;
            return intval($b['credits'] ?? 0) <=> intval($a['credits'] ?? 0);
        });
        
        // Assign ranks
        $rank = 1;
        foreach ($group as &$student) {
            if (isset($student['source']) && $student['source'] === 'archive' && isset($student['final_rank']) && $student['final_rank'] !== null) {
                $student['__rank'] = (int)$student['final_rank'];
            } else {
                $student['__rank'] = $rank;
            }
            $student['rank_change'] = $student['rank_change'] ?? 0;
            $student['is_new'] = false;
            $rank++;
        }
        unset($student);
    }

    // $allRows already fetched above (without search filter)
    $ranked = $rows;
    
    if (false) { // Disabled old ranking logic
    } else {
        // Old logic disabled - ranks are now calculated before filtering
    }

    // Calculate dashboard stats from ALL data (semester/academic year/course filters only, NOT search)
    $totalStudents = count($allRows);
    $avgGpa = $totalStudents ? round(array_sum(array_map(function($r){ return (float)$r['gpa']; }, $allRows)) / $totalStudents, 2) : null;
    $topPerformer = $allRows[0] ?? null;

    // Count distinct courses from all data (not affected by search)
    $coursesSet = [];
    foreach ($allRows as $r) {
        if (!empty($r['course'])) {
            $coursesSet[$r['course']] = true;
        }
    }
    $activeCourses = count($coursesSet);
} catch (PDOException $e) {
    error_log("[rankings.php] DB error: " . $e->getMessage());
    $ranked = [];
    $courseOptions = [];
    $semesterOptions = [];
    $academicYearOptions = [];
    $totalStudents = 0;
    $avgGpa = null;
    $topPerformer = null;
    $activeCourses = 0;
    $useArchive = false;
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Student Rankings - Dean's List</title>
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <!-- now using admin.css only -->
  <link rel="stylesheet" href="<?php echo asset('../admin/admin.css'); ?>">
</head>
<body>
  <header class="admin-header">
    <div class="header-content">
      <h1 class="portal-title">Admin Portal</h1>
      <nav class="main-nav">
        <a href="<?php echo asset('../admin/admin_homepage.php'); ?>">Home</a>
        <a href="<?php echo asset('../admin/admin_applications.php'); ?>">Status</a>
        <a href="<?php echo asset('rankings.php'); ?>" class="active">Rankings</a>
        <a href="<?php echo asset('../admin/admin_users.php'); ?>">Manage Users</a>
        <a href="<?php echo asset('../admin/admin_reports.php'); ?>">Reports</a>
      </nav>
      <div class="user-nav">
        <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['admin'] ?? 'Admin'); ?></span>
        <a href="<?php echo asset('../admin/admin_logout.php'); ?>">Logout</a>
      </div>
    </div>
  </header>

  <main class="container page-container">
    <div class="page-header" style="margin-bottom:18px;">
      <h2 style="margin:0 0 4px 0;">Student Rankings</h2>
      <p style="margin:0;color:#6b7280;">View and manage student academic rankings</p>
    </div>

    <div class="stats-grid" aria-hidden="false">
      <div class="card">
        <h4>Total Students</h4>
        <div class="value"><?php echo (int)$totalStudents; ?></div>
        <div style="color:#6b7280;font-size:13px;margin-top:8px;">Ranked this semester</div>
      </div>

      <div class="card">
        <h4>Average GPA</h4>
        <div class="value"><?php echo $avgGpa !== null ? htmlspecialchars(number_format($avgGpa,2)) : '—'; ?></div>
        <div style="color:#6b7280;font-size:13px;margin-top:8px;">Across all students</div>
      </div>

      <div class="card">
        <h4>Top Performer</h4>
        <div class="value"><?php echo $topPerformer ? htmlspecialchars($topPerformer['gpa']) : '—'; ?></div>
        <div style="color:#6b7280;font-size:13px;margin-top:8px;"><?php echo $topPerformer ? htmlspecialchars($topPerformer['full_name']) : ''; ?></div>
      </div>

      <div class="card">
        <h4>Active Courses</h4>
        <div class="value"><?php echo (int)$activeCourses; ?></div>
        <div style="color:#6b7280;font-size:13px;margin-top:8px;">Different programs</div>
      </div>
    </div>


    <div class="filters" role="search" aria-label="filters">
      <form id="filtersForm" method="get" style="display:flex;flex:1;gap:12px;align-items:center;width:100%;flex-wrap:wrap;">
        <input id="searchBox" name="q" type="text" placeholder="Search by name or ID..." value="<?php echo htmlspecialchars($search); ?>" style="min-width:200px;flex:1;">
        <select id="courseSelect" name="course" style="min-width:120px;">
          <option value="">All Courses</option>
          <?php foreach ($courseOptions as $c): ?>
            <option value="<?php echo htmlspecialchars($c); ?>" <?php echo ($filterCourse === $c) ? 'selected' : ''; ?>><?php echo htmlspecialchars($c); ?></option>
          <?php endforeach; ?>
        </select>
        <select id="yearLevelSelect" name="year_level" style="min-width:120px;">
          <option value="">All Year Levels</option>
          <?php foreach ($yearLevelOptions as $yl): ?>
            <option value="<?php echo htmlspecialchars($yl); ?>" <?php echo ($filterYearLevel === $yl) ? 'selected' : ''; ?>>Year <?php echo htmlspecialchars($yl); ?></option>
          <?php endforeach; ?>
        </select>
        <select id="semesterSelect" name="semester" style="min-width:120px;">
          <option value="">All Semesters</option>
          <option value="1st Semester" <?php echo ($filterSemester === '1st Semester') ? 'selected' : ''; ?>>1st Semester</option>
          <option value="2nd Semester" <?php echo ($filterSemester === '2nd Semester') ? 'selected' : ''; ?>>2nd Semester</option>
        </select>
        <select id="academicYearSelect" name="academic_year" style="min-width:120px;">
          <option value="">All Academic Years</option>
          <?php foreach ($academicYearOptions as $ay): ?>
            <option value="<?php echo htmlspecialchars($ay); ?>" <?php echo ($filterAcademicYear === $ay) ? 'selected' : ''; ?>><?php echo htmlspecialchars($ay); ?></option>
          <?php endforeach; ?>
        </select>
        <div style="display:flex;gap:8px;flex-shrink:0;">
          <button type="submit" id="applyBtn" class="apply-filters">Apply</button>
          <button type="button" id="clearBtn" class="clear-filters">Clear</button>
        </div>
      </form>
    </div>

    <div class="table-card" role="region" aria-label="student rankings">
      <h3 style="margin:0 0 6px 0;">Student Rankings<?php if ($filterSemester) echo ' - ' . htmlspecialchars($filterSemester); ?><?php if ($filterAcademicYear) echo ' (' . htmlspecialchars($filterAcademicYear) . ')'; ?><?php if ($useArchive) echo ' (Archive)'; ?></h3>
      <p style="color:#6b7280;margin:6px 0 18px 0;">Academic performance rankings based on GPA and course performance<?php if ($useArchive) echo ' - Historical Data'; ?></p>

      <div class="applications-table">
        <table aria-describedby="rankingsTable">
          <thead>
            <tr>
              <th style="width:80px">Rank</th>
              <th>Student</th>
              <th>Course</th>
              <th style="width:80px">Year</th>
              <th style="width:100px">GPA</th>
              <th style="width:120px">Semester</th>
              <th style="width:120px">Academic Year</th>
            </tr>
          </thead>
          <tbody id="rankingsBody">
            <?php if (empty($ranked)): ?>
              <tr><td colspan="7" style="color:#6b7280;padding:18px;text-align:center;">No rankings found<?php if ($filterSemester || $filterAcademicYear || $filterCourse) echo ' for the selected filters'; ?>.</td></tr>
            <?php else: ?>
              <?php foreach ($ranked as $r): ?>
                <tr data-student="<?php echo htmlspecialchars($r['full_name']); ?>" data-course="<?php echo htmlspecialchars($r['course']); ?>">
                  <td>
                    <div class="rank-ico">
                      <?php
                        $rk = (int)$r['__rank'];
                        if ($rk === 1) echo '🏆 #1';
                        elseif ($rk === 2) echo '🥈 #2';
                        elseif ($rk === 3) echo '🥉 #3';
                        else echo '#' . $rk;
                      ?>
                    </div>
                  </td>
                  <td>
                    <div style="font-weight:600;"><?php echo htmlspecialchars($r['full_name']); ?></div>
                    <div style="color:#6b7280;font-size:13px;"><?php echo htmlspecialchars($r['student_id']); ?></div>
                  </td>
                  <td><span class="badge"><?php echo htmlspecialchars($r['course']); ?></span></td>
                  <td><span class="badge"><?php echo htmlspecialchars($r['year_level']); ?></span></td>
                  <td style="font-weight:600;"><?php echo htmlspecialchars($r['gpa']); ?></td>
                  <td><?php 
                    $semNum = $r['semester_number'] ?? '';
                    $semDisplay = ($semNum == '1') ? '1st Semester' : (($semNum == '2') ? '2nd Semester' : '');
                    echo htmlspecialchars($semDisplay);
                  ?></td>
                  <td><?php echo htmlspecialchars($r['academic_year']); ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>

<script>
(function(){
  const clearBtn = document.getElementById('clearBtn');
  if (clearBtn) {
    clearBtn.addEventListener('click', function(){
      // use json_encoded URL to safely include PHP string inside JS
      window.location.href = <?php echo json_encode(asset('rankings.php')); ?>;
    });
  }

  // Enter in search triggers submit
  const searchBox = document.getElementById('searchBox');
  if (searchBox) {
    searchBox.addEventListener('keydown', function(e){
      if (e.key === 'Enter') {
        e.preventDefault();
        const form = document.getElementById('filtersForm');
        if (form) form.submit();
      }
    });
  }
})();
</script>
</body>
</html>
