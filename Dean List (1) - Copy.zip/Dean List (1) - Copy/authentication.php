<?php
session_start();

// Function to check if user is logged in
function check_login() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }
}

// Function to check if user is a student
function ensure_student_role() {
    check_login();
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
        header("Location: index.php");
        exit();
    }
}

// Function to check if user is an admin
function ensure_admin_role() {
    check_login();
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        header("Location: index.php");
        exit();
    }
}
?>