<?php
class Database {
    private $conn;
    
    public function getConnection() {
        $this->conn = null;
        
        // Always use Hostinger database credentials
        $host = 'localhost';
        $db_name = 'u832832306_deanlist';
        $username = 'u832832306_deanuser';
        $password = 'lSPUDLACSS1!!';
        
        try {
            $this->conn = new PDO(
                "mysql:host=" . $host . ";dbname=" . $db_name,
                $username,
                $password
            );
            $this->conn->exec("set names utf8");
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Auto-create tables if they don't exist
            $this->createTablesIfNotExist();
            
        } catch(PDOException $exception) {
            echo "Connection error: " . $exception->getMessage();
        }
        
        return $this->conn;
    }
    
    private function createTablesIfNotExist() {
        $tables = [
            "CREATE TABLE IF NOT EXISTS users (
                user_id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(255) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                role ENUM('student', 'admin') DEFAULT 'student',
                student_id VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )",
            
            "CREATE TABLE IF NOT EXISTS students (
                id INT AUTO_INCREMENT PRIMARY KEY,
                student_id VARCHAR(20) UNIQUE NOT NULL,
                full_name VARCHAR(255) NOT NULL,
                course VARCHAR(10),
                year_level INT,
                profile_picture VARCHAR(500),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )",
            
            "CREATE TABLE IF NOT EXISTS applications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT,
                student_id VARCHAR(20),
                gpa DECIMAL(3,2),
                total_units INT,
                semID INT,
                acadID INT,
                file_path VARCHAR(500),
                status ENUM('under-review', 'accepted', 'rejected') DEFAULT 'under-review',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )",
            
            "CREATE TABLE IF NOT EXISTS acad_year (
                acadID INT AUTO_INCREMENT PRIMARY KEY,
                academic_year VARCHAR(20),
                start_date DATE,
                end_date DATE
            )",
            
            "CREATE TABLE IF NOT EXISTS semester (
                semID INT AUTO_INCREMENT PRIMARY KEY,
                semester_name VARCHAR(50),
                acadID INT
            )",
            
            "CREATE TABLE IF NOT EXISTS current_semester (
                id INT AUTO_INCREMENT PRIMARY KEY,
                semester_number INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )",
            
            "CREATE TABLE IF NOT EXISTS application_status (
                id INT AUTO_INCREMENT PRIMARY KEY,
                status ENUM('open', 'closed') DEFAULT 'open',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )",
            
            "CREATE TABLE IF NOT EXISTS email_verifications (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(255) UNIQUE,
                verification_code VARCHAR(6),
                student_data TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )",
            
            "CREATE TABLE IF NOT EXISTS student_rankings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                student_id VARCHAR(20),
                full_name VARCHAR(255),
                course VARCHAR(10),
                year_level INT,
                gpa DECIMAL(3,2),
                credits INT,
                semID INT,
                acadID INT,
                rank_change INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )",
            
            "CREATE TABLE IF NOT EXISTS rankings_archive (
                id INT AUTO_INCREMENT PRIMARY KEY,
                student_id VARCHAR(20),
                full_name VARCHAR(255),
                course VARCHAR(10),
                year_level INT,
                gpa DECIMAL(3,2),
                final_rank INT,
                semID INT,
                acadID INT,
                archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )",
            
            "CREATE TABLE IF NOT EXISTS password_resets (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(255) UNIQUE,
                token VARCHAR(64),
                verification_code VARCHAR(6),
                expires_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )"
        ];
        
        foreach ($tables as $sql) {
            try {
                $this->conn->exec($sql);
            } catch(PDOException $e) {
                // Continue if table creation fails
            }
        }
        
        // Insert default data if tables are empty
        $this->insertDefaultData();
    }
    
    private function insertDefaultData() {
        try {
            // Check if admin user exists
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin'");
            $stmt->execute();
            
            if ($stmt->fetchColumn() == 0) {
                // Create default admin
                $admin_sql = "INSERT INTO users (email, password, role) VALUES ('admin@lspu.edu.ph', 'admin123', 'admin')";
                $this->conn->exec($admin_sql);
                
                // Create default academic year
                $acad_sql = "INSERT INTO acad_year (academic_year, start_date, end_date) VALUES ('2024-2025', '2024-08-01', '2025-07-31')";
                $this->conn->exec($acad_sql);
                
                // Create default semester
                $sem_sql = "INSERT INTO semester (semester_name, acadID) VALUES ('1st Semester', 1)";
                $this->conn->exec($sem_sql);
                
                // Set current semester
                $current_sem_sql = "INSERT INTO current_semester (semester_number) VALUES (1)";
                $this->conn->exec($current_sem_sql);
                
                // Set application status
                $status_sql = "INSERT INTO application_status (status) VALUES ('open')";
                $this->conn->exec($status_sql);
            }
        } catch(PDOException $e) {
            // Continue if default data insertion fails
        }
    }
}
?>