<?php
// Password reset email configuration - separate from registration
class PasswordResetEmail {
    
    public function sendPasswordResetEmail($to_email, $verification_code, $student_name, $reset_token) {
        $reset_link = "https://ccsdlapplication.online/student/forgot_password.php?token=" . $reset_token . "&email=" . urlencode($to_email);
        
        $subject = "Password Reset - Dean's List Application";
        
        $message = $this->getPasswordResetHTML($verification_code, $student_name, $reset_link);
        
        $headers = array(
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=UTF-8',
            'From: Dean\'s List System <noreply@ccsdlapplication.online>',
            'Reply-To: noreply@ccsdlapplication.online',
            'X-Mailer: PHP/' . phpversion()
        );
        
        $result = mail($to_email, $subject, $message, implode("\r\n", $headers));
        
        if (!$result) {
            error_log("Password reset email failed to send to: " . $to_email);
        }
        
        return $result;
    }
    
    private function getPasswordResetHTML($code, $studentName, $resetLink) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Password Reset</title>
        </head>
        <body style='font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f4f4f4;'>
            <div style='max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
                <div style='background: #7e1516; color: white; padding: 30px; text-align: center;'>
                    <h1 style='margin: 0; font-size: 28px;'>Dean's List System</h1>
                    <p style='margin: 10px 0 0 0; font-size: 16px; opacity: 0.9;'>Password Reset Request</p>
                </div>
                <div style='padding: 40px 30px;'>
                    <h2 style='color: #7e1516; margin: 0 0 20px 0;'>Hello " . htmlspecialchars($studentName) . "!</h2>
                    <p style='font-size: 16px; line-height: 1.6; color: #333; margin: 0 0 25px 0;'>
                        You requested to reset your password. Click the button below to reset it:
                    </p>
                    <div style='background: #f8f9fa; border: 2px solid #7e1516; border-radius: 10px; padding: 25px; text-align: center; margin: 25px 0;'>
                        <a href='" . $resetLink . "' style='display: inline-block; background: #7e1516; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 16px;'>Reset My Password</a>
                    </div>
                    <p style='color: #856404; font-size: 14px; text-align: center;'>This link expires in 1 hour.</p>
                    <p style='font-size: 12px; color: #999; text-align: center; margin-top: 20px;'>If the button doesn't work, copy and paste this link:<br>" . $resetLink . "</p>
                </div>
            </div>
        </body>
        </html>";
    }
}
?>