<?php
// Simple email configuration without PHPMailer
class EmailConfig {
    
    public function sendVerificationEmail($to_email, $verification_code, $student_name) {
        // Use PHP's built-in mail function with proper headers
        $subject = "Email Verification - Dean's List Registration";
        
        $message = $this->getEmailHTML($verification_code, $student_name);
        
        // Set proper headers for HTML email
        $headers = array(
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=UTF-8',
            'From: Dean\'s List System <noreply@ccsdlapplication.online>',
            'Reply-To: noreply@ccsdlapplication.online',
            'X-Mailer: PHP/' . phpversion()
        );
        
        // Try to send email
        $result = mail($to_email, $subject, $message, implode("\r\n", $headers));
        
        if (!$result) {
            error_log("Email failed to send to: " . $to_email);
        }
        
        return $result;
    }
    
    public function sendPasswordResetEmail($to_email, $verification_code, $student_name, $reset_token) {
        $reset_link = "https://ccsdlapplication.online/student/forgot_password.php?token=" . $reset_token . "&email=" . urlencode($to_email);
        
        $subject = "Password Reset - Dean's List Application";
        
        $message = $this->getPasswordResetHTML($verification_code, $student_name, $reset_link);
        
        $headers = array(
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=UTF-8',
            'From: Dean\'s List System <noreply@ccsdlapplication.online>',
            'Reply-To: noreply@ccsdlapplication.online',
            'X-Mailer: PHP/' . phpversion()
        );
        
        $result = mail($to_email, $subject, $message, implode("\r\n", $headers));
        
        if (!$result) {
            error_log("Password reset email failed to send to: " . $to_email);
        }
        
        return $result;
    }
    
    private function getEmailHTML($code, $studentName) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Email Verification</title>
        </head>
        <body style='font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f4f4f4;'>
            <div style='max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
                
                <!-- Header -->
                <div style='background: #2e55a6; color: white; padding: 30px; text-align: center;'>
                    <h1 style='margin: 0; font-size: 28px;'>Dean's List System</h1>
                    <p style='margin: 10px 0 0 0; font-size: 16px; opacity: 0.9;'>Email Verification Required</p>
                </div>
                
                <!-- Content -->
                <div style='padding: 40px 30px;'>
                    <h2 style='color: #2e55a6; margin: 0 0 20px 0;'>Hello " . htmlspecialchars($studentName) . "!</h2>
                    
                    <p style='font-size: 16px; line-height: 1.6; color: #333; margin: 0 0 25px 0;'>
                        Thank you for registering for the Dean's List application system. To complete your registration, please verify your email address using the code below.
                    </p>
                    
                    <!-- Verification Code Box -->
                    <div style='background: #f8f9fa; border: 3px solid #2e55a6; border-radius: 10px; padding: 25px; text-align: center; margin: 25px 0;'>
                        <p style='margin: 0 0 15px 0; font-size: 14px; color: #666; text-transform: uppercase; letter-spacing: 1px;'>Your Verification Code</p>
                        <div style='font-size: 36px; font-weight: bold; color: #2e55a6; letter-spacing: 8px; font-family: monospace;'>" . $code . "</div>
                    </div>
                    
                    <!-- Instructions -->
                    <div style='background: #e3f2fd; border-left: 4px solid #2e55a6; padding: 20px; margin: 25px 0;'>
                        <h3 style='margin: 0 0 15px 0; color: #2e55a6; font-size: 18px;'>Next Steps:</h3>
                        <ol style='margin: 0; padding-left: 20px; color: #333;'>
                            <li style='margin-bottom: 8px;'>Return to the registration page</li>
                            <li style='margin-bottom: 8px;'>Enter the 6-digit code above</li>
                            <li style='margin-bottom: 8px;'>Complete your registration</li>
                        </ol>
                    </div>
                    
                    <div style='background: #fff3cd; border: 1px solid #ffeaa7; border-radius: 5px; padding: 15px; margin: 25px 0;'>
                        <p style='margin: 0; color: #856404; font-size: 14px;'>
                            <strong>⚠️ Important:</strong> This verification code will expire in 15 minutes for security purposes.
                        </p>
                    </div>
                </div>
                
                <!-- Footer -->
                <div style='background: #f8f9fa; padding: 20px 30px; border-top: 1px solid #e9ecef;'>
                    <p style='margin: 0; font-size: 12px; color: #6c757d; text-align: center;'>
                        If you didn't request this verification, please ignore this email.<br>
                        This is an automated message from the Dean's List Application System.
                    </p>
                </div>
            </div>
        </body>
        </html>";
    }
    
    private function getPasswordResetHTML($code, $studentName, $resetLink) {
        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <title>Password Reset</title>
        </head>
        <body style='font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f4f4f4;'>
            <div style='max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
                <div style='background: #7e1516; color: white; padding: 30px; text-align: center;'>
                    <h1 style='margin: 0; font-size: 28px;'>Dean's List System</h1>
                    <p style='margin: 10px 0 0 0; font-size: 16px; opacity: 0.9;'>Password Reset Request</p>
                </div>
                <div style='padding: 40px 30px;'>
                    <h2 style='color: #7e1516; margin: 0 0 20px 0;'>Hello " . htmlspecialchars($studentName) . "!</h2>
                    <p style='font-size: 16px; line-height: 1.6; color: #333; margin: 0 0 25px 0;'>
                        You requested to reset your password. Use either method below:
                    </p>
                    <div style='background: #f8f9fa; border: 2px solid #7e1516; border-radius: 10px; padding: 25px; text-align: center; margin: 25px 0;'>
                        <h3 style='margin: 0 0 15px 0; color: #7e1516;'>Method 1: Click Reset Link</h3>
                        <a href='" . $resetLink . "' style='display: inline-block; background: #7e1516; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;'>Reset Password</a>
                    </div>
                    <div style='background: #f8f9fa; border: 2px solid #7e1516; border-radius: 10px; padding: 25px; text-align: center; margin: 25px 0;'>
                        <h3 style='margin: 0 0 15px 0; color: #7e1516;'>Method 2: Use Code</h3>
                        <div style='font-size: 36px; font-weight: bold; color: #7e1516; letter-spacing: 8px; font-family: monospace;'>" . $code . "</div>
                    </div>
                    <p style='color: #856404; font-size: 14px; text-align: center;'>This expires in 1 hour.</p>
                </div>
            </div>
        </body>
        </html>";
    }
}
?>